/* ═══════════════════════════════════════════════
   LibraBot — Chat Frontend
   ═══════════════════════════════════════════════ */

const messages    = document.getElementById("messages");
const userInput   = document.getElementById("userInput");
const sendBtn     = document.getElementById("sendBtn");
const typingStatus = document.getElementById("typingStatus");

// ── Helpers ──────────────────────────────────────────────────────────────

function now() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function scrollBottom() {
    messages.scrollTop = messages.scrollHeight;
}

function escHtml(str) {
    const d = document.createElement("div");
    d.appendChild(document.createTextNode(str));
    return d.innerHTML;
}

/**
 * Lightweight markdown renderer for bot messages.
 * Handles: **bold**, *italic*, `code`, bullet lines, numbered lines.
 */
function renderMarkdown(text) {
    let html = escHtml(text);

    // Bold
    html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    // Italic (single asterisk or underscore)
    html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");
    // Inline code
    html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
    // Line breaks
    html = html.replace(/\n/g, "<br>");

    return html;
}

// ── Stats bar ─────────────────────────────────────────────────────────────

async function loadStats() {
    try {
        const res  = await fetch("/api/stats");
        const data = await res.json();
        document.getElementById("statBooksVal").textContent   = data.total_books;
        document.getElementById("statMembersVal").textContent = data.total_members;
        document.getElementById("statBorrowsVal").textContent = data.active_borrows;
        document.getElementById("statOverdueVal").textContent = data.overdue;

        const pill = document.getElementById("statOverdue");
        if (data.overdue > 0) {
            pill.style.borderColor = "rgba(251,191,36,0.5)";
        }
    } catch (_) { /* silently ignore */ }
}

// ── Message rendering ─────────────────────────────────────────────────────

function appendUserMsg(text) {
    const row = document.createElement("div");
    row.className = "msg-row user";
    row.innerHTML = `
        <div class="msg-bubble">
            ${escHtml(text)}
            <span class="msg-time">${now()}</span>
        </div>
        <div class="msg-avatar">🧑</div>
    `;
    messages.appendChild(row);
    scrollBottom();
}

function appendBotMsg(text) {
    const row = document.createElement("div");
    row.className = "msg-row bot";
    row.innerHTML = `
        <div class="msg-avatar">🤖</div>
        <div class="msg-bubble">
            ${renderMarkdown(text)}
            <span class="msg-time">${now()}</span>
        </div>
    `;
    messages.appendChild(row);
    scrollBottom();
}

function showTyping() {
    const row = document.createElement("div");
    row.className = "msg-row bot typing-bubble";
    row.id = "typingBubble";
    row.innerHTML = `
        <div class="msg-avatar">🤖</div>
        <div class="msg-bubble">
            <div class="dots"><span></span><span></span><span></span></div>
        </div>
    `;
    messages.appendChild(row);
    scrollBottom();
}

function hideTyping() {
    const el = document.getElementById("typingBubble");
    if (el) el.remove();
}

// ── Loading state ─────────────────────────────────────────────────────────

function setLoading(on) {
    sendBtn.disabled  = on;
    userInput.disabled = on;
    typingStatus.textContent = on ? "typing..." : "AI Library Assistant";
    typingStatus.className   = on ? "ch-sub typing" : "ch-sub";
}

// ── Send message ──────────────────────────────────────────────────────────

async function sendMessage(e) {
    if (e) e.preventDefault();
    const text = userInput.value.trim();
    if (!text) return;

    userInput.value = "";
    appendUserMsg(text);
    setLoading(true);
    showTyping();

    const delay = 500 + Math.random() * 500;

    try {
        const res = await fetch("/chat", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ message: text }),
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();

        await new Promise(r => setTimeout(r, delay));
        hideTyping();
        appendBotMsg(data.response);

        // Refresh stats after any action
        loadStats();
    } catch (err) {
        await new Promise(r => setTimeout(r, delay));
        hideTyping();
        appendBotMsg("⚠️ Something went wrong. Please try again.");
        console.error(err);
    } finally {
        setLoading(false);
        userInput.focus();
    }
}

// ── Suggestion / sidebar click ────────────────────────────────────────────

function sendSuggestion(text) {
    userInput.value = text;
    sendMessage(null);
}

// ── Clear chat ────────────────────────────────────────────────────────────

function clearChat() {
    messages.innerHTML = "";
    showWelcome();
    userInput.focus();
}

// ── Welcome message ───────────────────────────────────────────────────────

function showWelcome() {
    appendBotMsg(
        "👋 Welcome to **LibraBot** — your AI-powered Library Management System!\n\n" +
        "I can help you manage books, members, and borrowing records using natural language.\n\n" +
        "**Try asking:**\n" +
        "• *search Harry Potter*\n" +
        "• *available books*\n" +
        "• *borrow book 3 member 1*\n" +
        "• *overdue books*\n" +
        "• *stats*\n\n" +
        "Type **help** to see all commands. What would you like to do?"
    );
}

// ── Keyboard shortcut ─────────────────────────────────────────────────────

userInput.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        sendMessage(null);
    }
});

// ── Init ──────────────────────────────────────────────────────────────────

window.addEventListener("load", () => {
    showWelcome();
    loadStats();
    userInput.focus();
});
