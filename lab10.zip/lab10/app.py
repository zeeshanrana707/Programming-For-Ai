from flask import Flask, render_template, request, jsonify
import sqlite3
import re
import random
from datetime import datetime, timedelta
import os

app = Flask(__name__)
DB_PATH = "library.db"

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables and seed sample data on first run."""
    conn = get_db()
    c = conn.cursor()

    c.executescript("""
        CREATE TABLE IF NOT EXISTS books (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            title       TEXT NOT NULL,
            author      TEXT NOT NULL,
            genre       TEXT NOT NULL,
            year        INTEGER,
            isbn        TEXT UNIQUE,
            copies      INTEGER DEFAULT 1,
            available   INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS members (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL,
            email       TEXT UNIQUE NOT NULL,
            joined      TEXT DEFAULT (date('now')),
            active      INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS borrows (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id     INTEGER NOT NULL REFERENCES books(id),
            member_id   INTEGER NOT NULL REFERENCES members(id),
            borrow_date TEXT DEFAULT (date('now')),
            due_date    TEXT,
            return_date TEXT,
            status      TEXT DEFAULT 'borrowed'
        );
    """)

    # Seed books if empty
    count = c.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    if count == 0:
        books = [
            ("The Great Gatsby",        "F. Scott Fitzgerald", "Classic",       1925, "978-0743273565", 3, 3),
            ("To Kill a Mockingbird",   "Harper Lee",          "Classic",       1960, "978-0061935466", 2, 2),
            ("1984",                    "George Orwell",       "Dystopian",     1949, "978-0451524935", 4, 4),
            ("Brave New World",         "Aldous Huxley",       "Dystopian",     1932, "978-0060850524", 2, 2),
            ("The Hobbit",              "J.R.R. Tolkien",      "Fantasy",       1937, "978-0547928227", 3, 3),
            ("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "Fantasy", 1997, "978-0439708180", 5, 5),
            ("The Da Vinci Code",       "Dan Brown",           "Thriller",      2003, "978-0307474278", 3, 3),
            ("Gone Girl",              "Gillian Flynn",        "Thriller",      2012, "978-0307588371", 2, 2),
            ("Sapiens",                "Yuval Noah Harari",    "Non-Fiction",   2011, "978-0062316097", 3, 3),
            ("Atomic Habits",          "James Clear",          "Self-Help",     2018, "978-0735211292", 4, 4),
            ("The Alchemist",          "Paulo Coelho",         "Fiction",       1988, "978-0062315007", 3, 3),
            ("Pride and Prejudice",    "Jane Austen",          "Classic",       1813, "978-0141439518", 2, 2),
            ("The Catcher in the Rye", "J.D. Salinger",       "Classic",       1951, "978-0316769174", 2, 2),
            ("Dune",                   "Frank Herbert",        "Sci-Fi",        1965, "978-0441013593", 3, 3),
            ("The Martian",            "Andy Weir",            "Sci-Fi",        2011, "978-0553418026", 2, 2),
        ]
        c.executemany(
            "INSERT INTO books (title, author, genre, year, isbn, copies, available) VALUES (?,?,?,?,?,?,?)",
            books
        )

    # Seed members if empty
    count = c.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    if count == 0:
        members = [
            ("Alice Johnson", "alice@example.com"),
            ("Bob Smith",     "bob@example.com"),
            ("Carol White",   "carol@example.com"),
            ("David Brown",   "david@example.com"),
        ]
        c.executemany("INSERT INTO members (name, email) VALUES (?,?)", members)

    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Library data-access functions
# ---------------------------------------------------------------------------

def search_books(query: str):
    conn = get_db()
    q = f"%{query}%"
    rows = conn.execute(
        """SELECT * FROM books
           WHERE title LIKE ? OR author LIKE ? OR genre LIKE ? OR isbn LIKE ?
           ORDER BY title""",
        (q, q, q, q)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_books():
    conn = get_db()
    rows = conn.execute("SELECT * FROM books ORDER BY title").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_available_books():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM books WHERE available > 0 ORDER BY title"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_book_by_id(book_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def add_book(title, author, genre, year, isbn, copies):
    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO books (title, author, genre, year, isbn, copies, available) VALUES (?,?,?,?,?,?,?)",
            (title, author, genre, year, isbn, copies, copies)
        )
        conn.commit()
        return True, "Book added successfully."
    except sqlite3.IntegrityError:
        return False, "A book with that ISBN already exists."
    finally:
        conn.close()


def borrow_book(book_id: int, member_id: int):
    conn = get_db()
    book = conn.execute("SELECT * FROM books WHERE id=?", (book_id,)).fetchone()
    if not book:
        conn.close()
        return False, "Book not found."
    if book["available"] < 1:
        conn.close()
        return False, f'Sorry, **{book["title"]}** is currently unavailable. All copies are checked out.'

    # Check if member already has this book
    existing = conn.execute(
        "SELECT id FROM borrows WHERE book_id=? AND member_id=? AND status='borrowed'",
        (book_id, member_id)
    ).fetchone()
    if existing:
        conn.close()
        return False, "This member already has a copy of that book checked out."

    due = (datetime.now() + timedelta(days=14)).strftime("%Y-%m-%d")
    conn.execute(
        "INSERT INTO borrows (book_id, member_id, due_date) VALUES (?,?,?)",
        (book_id, member_id, due)
    )
    conn.execute("UPDATE books SET available = available - 1 WHERE id=?", (book_id,))
    conn.commit()
    conn.close()
    return True, f'✅ **{book["title"]}** has been checked out. Due back by **{due}**.'


def return_book(book_id: int, member_id: int):
    conn = get_db()
    borrow = conn.execute(
        "SELECT b.id, bk.title FROM borrows b JOIN books bk ON b.book_id=bk.id "
        "WHERE b.book_id=? AND b.member_id=? AND b.status='borrowed'",
        (book_id, member_id)
    ).fetchone()
    if not borrow:
        conn.close()
        return False, "No active borrow record found for that book and member."

    today = datetime.now().strftime("%Y-%m-%d")
    conn.execute(
        "UPDATE borrows SET return_date=?, status='returned' WHERE id=?",
        (today, borrow["id"])
    )
    conn.execute("UPDATE books SET available = available + 1 WHERE id=?", (book_id,))
    conn.commit()
    conn.close()
    return True, f'✅ **{borrow["title"]}** has been returned. Thank you!'


def get_member_borrows(member_id: int):
    conn = get_db()
    rows = conn.execute(
        """SELECT b.id, bk.title, bk.author, b.borrow_date, b.due_date, b.status
           FROM borrows b JOIN books bk ON b.book_id = bk.id
           WHERE b.member_id=? ORDER BY b.borrow_date DESC""",
        (member_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_overdue_books():
    today = datetime.now().strftime("%Y-%m-%d")
    conn = get_db()
    rows = conn.execute(
        """SELECT bk.title, bk.author, m.name, m.email, b.due_date,
                  julianday('now') - julianday(b.due_date) AS days_overdue
           FROM borrows b
           JOIN books bk ON b.book_id = bk.id
           JOIN members m ON b.member_id = m.id
           WHERE b.status='borrowed' AND b.due_date < ?
           ORDER BY b.due_date""",
        (today,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_members():
    conn = get_db()
    rows = conn.execute("SELECT * FROM members ORDER BY name").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def find_member(query: str):
    conn = get_db()
    q = f"%{query}%"
    rows = conn.execute(
        "SELECT * FROM members WHERE name LIKE ? OR email LIKE ?", (q, q)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_member(name: str, email: str):
    conn = get_db()
    try:
        conn.execute("INSERT INTO members (name, email) VALUES (?,?)", (name, email))
        conn.commit()
        return True, f'✅ Member **{name}** registered successfully.'
    except sqlite3.IntegrityError:
        return False, "A member with that email already exists."
    finally:
        conn.close()


def get_stats():
    conn = get_db()
    total_books   = conn.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    total_copies  = conn.execute("SELECT SUM(copies) FROM books").fetchone()[0] or 0
    avail_copies  = conn.execute("SELECT SUM(available) FROM books").fetchone()[0] or 0
    total_members = conn.execute("SELECT COUNT(*) FROM members").fetchone()[0]
    active_borrows= conn.execute("SELECT COUNT(*) FROM borrows WHERE status='borrowed'").fetchone()[0]
    today = datetime.now().strftime("%Y-%m-%d")
    overdue       = conn.execute(
        "SELECT COUNT(*) FROM borrows WHERE status='borrowed' AND due_date < ?", (today,)
    ).fetchone()[0]
    conn.close()
    return {
        "total_books":    total_books,
        "total_copies":   total_copies,
        "avail_copies":   avail_copies,
        "total_members":  total_members,
        "active_borrows": active_borrows,
        "overdue":        overdue,
    }


# ---------------------------------------------------------------------------
# AI-oriented NLP chatbot engine
# ---------------------------------------------------------------------------

def format_book_list(books, max_items=8):
    if not books:
        return "No books found."
    lines = []
    for b in books[:max_items]:
        avail = f"✅ {b['available']} available" if b['available'] > 0 else "❌ Unavailable"
        lines.append(f"📖 **{b['title']}** by *{b['author']}* ({b['genre']}, {b['year']}) — {avail} [ID: {b['id']}]")
    if len(books) > max_items:
        lines.append(f"*...and {len(books) - max_items} more results.*")
    return "\n".join(lines)


def format_member_list(members):
    if not members:
        return "No members found."
    lines = []
    for m in members:
        lines.append(f"👤 **{m['name']}** ({m['email']}) — Joined: {m['joined']} [ID: {m['id']}]")
    return "\n".join(lines)


def process_message(msg: str) -> str:
    """
    NLP-style intent detection and response generation.
    Handles library-specific intents with pattern matching + context.
    """
    text = msg.strip()
    lower = text.lower()

    # ── Greetings ──────────────────────────────────────────────────────────
    if re.search(r"\b(hello|hi|hey|good morning|good afternoon|good evening|greetings)\b", lower):
        return (
            "👋 Hello! I'm **LibraBot**, your AI library assistant.\n\n"
            "I can help you:\n"
            "• 🔍 Search for books by title, author, or genre\n"
            "• 📚 Check book availability\n"
            "• 📤 Borrow or return books\n"
            "• 👤 Register or look up members\n"
            "• 📊 View library statistics\n"
            "• ⚠️ Check overdue books\n\n"
            "What would you like to do today?"
        )

    # ── Help / capabilities ────────────────────────────────────────────────
    if re.search(r"\b(help|what can you do|capabilities|commands|how to use)\b", lower):
        return (
            "Here's what I can do for you:\n\n"
            "**📚 Books**\n"
            "• *search [title/author/genre]* — find books\n"
            "• *show all books* — list entire catalog\n"
            "• *available books* — only books in stock\n"
            "• *add book* — add a new book to the catalog\n\n"
            "**👤 Members**\n"
            "• *find member [name/email]* — look up a member\n"
            "• *all members* — list all members\n"
            "• *add member [name] [email]* — register a new member\n\n"
            "**📤 Borrowing**\n"
            "• *borrow book [book id] member [member id]* — check out a book\n"
            "• *return book [book id] member [member id]* — return a book\n"
            "• *borrows for member [id]* — see a member's history\n\n"
            "**📊 Reports**\n"
            "• *stats* or *statistics* — library overview\n"
            "• *overdue* — list overdue books\n"
        )

    # ── Statistics ─────────────────────────────────────────────────────────
    if re.search(r"\b(stats|statistics|overview|summary|dashboard)\b", lower):
        s = get_stats()
        checked_out = s['total_copies'] - s['avail_copies']
        return (
            "📊 **Library Statistics**\n\n"
            f"📖 Total titles: **{s['total_books']}**\n"
            f"📦 Total copies: **{s['total_copies']}**\n"
            f"✅ Available copies: **{s['avail_copies']}**\n"
            f"📤 Checked out: **{checked_out}**\n"
            f"👥 Registered members: **{s['total_members']}**\n"
            f"🔄 Active borrows: **{s['active_borrows']}**\n"
            f"⚠️ Overdue: **{s['overdue']}**"
        )

    # ── Overdue books ──────────────────────────────────────────────────────
    if re.search(r"\b(overdue|late|past due|not returned)\b", lower):
        items = get_overdue_books()
        if not items:
            return "✅ Great news — no overdue books right now!"
        lines = [f"⚠️ **{len(items)} overdue book(s):**\n"]
        for item in items:
            days = int(item['days_overdue'])
            lines.append(
                f"📖 **{item['title']}** — borrowed by *{item['name']}* "
                f"({item['email']}) — due **{item['due_date']}** "
                f"(**{days} day{'s' if days != 1 else ''} overdue**)"
            )
        return "\n".join(lines)

    # ── Show all books ─────────────────────────────────────────────────────
    if re.search(r"\b(all books|list books|show books|catalog|catalogue|every book)\b", lower):
        books = get_all_books()
        return f"📚 **Library Catalog — {len(books)} titles:**\n\n" + format_book_list(books, max_items=10)

    # ── Available books ────────────────────────────────────────────────────
    if re.search(r"\b(available books?|books? available|in stock|can borrow)\b", lower):
        books = get_available_books()
        return f"✅ **{len(books)} books currently available:**\n\n" + format_book_list(books)

    # ── Search books ───────────────────────────────────────────────────────
    search_match = re.search(
        r"\b(search|find|look up|lookup|show me|do you have|looking for)\b.{0,10}(?:book[s]?)?\s+(?:by\s+|about\s+|called\s+|titled\s+|named\s+)?[\"']?(.+?)[\"']?\s*$",
        lower
    )
    if search_match:
        query = search_match.group(2).strip()
        books = search_books(query)
        if books:
            return f"🔍 Found **{len(books)}** result(s) for *\"{query}\"*:\n\n" + format_book_list(books)
        return f"😕 No books found matching *\"{query}\"*. Try a different title, author, or genre."

    # Fallback: bare keyword search if message is short and looks like a title/author
    if len(lower.split()) <= 5 and not re.search(
        r"\b(borrow|return|add|register|member|stat|overdue|available|all|list)\b", lower
    ):
        books = search_books(text)
        if books:
            return f"🔍 Here's what I found for *\"{text}\"*:\n\n" + format_book_list(books)

    # ── Borrow book ────────────────────────────────────────────────────────
    borrow_match = re.search(
        r"\bborrow\b.*?book\s+(?:id\s*[:#]?\s*)?(\d+).*?member\s+(?:id\s*[:#]?\s*)?(\d+)",
        lower
    )
    if borrow_match:
        book_id   = int(borrow_match.group(1))
        member_id = int(borrow_match.group(2))
        ok, msg_out = borrow_book(book_id, member_id)
        return msg_out

    # ── Return book ────────────────────────────────────────────────────────
    return_match = re.search(
        r"\breturn\b.*?book\s+(?:id\s*[:#]?\s*)?(\d+).*?member\s+(?:id\s*[:#]?\s*)?(\d+)",
        lower
    )
    if return_match:
        book_id   = int(return_match.group(1))
        member_id = int(return_match.group(2))
        ok, msg_out = return_book(book_id, member_id)
        return msg_out

    # ── Member borrow history ──────────────────────────────────────────────
    history_match = re.search(
        r"\b(borrow(?:s|ed|ing)?|history|books? (?:for|of))\b.*?member\s+(?:id\s*[:#]?\s*)?(\d+)",
        lower
    )
    if history_match:
        member_id = int(history_match.group(2))
        records = get_member_borrows(member_id)
        if not records:
            return f"No borrow records found for member ID {member_id}."
        lines = [f"📋 **Borrow history for member #{member_id}:**\n"]
        for r in records:
            icon = "🔄" if r['status'] == 'borrowed' else "✅"
            lines.append(
                f"{icon} **{r['title']}** by *{r['author']}* — "
                f"Borrowed: {r['borrow_date']} | Due: {r['due_date']} | Status: *{r['status']}*"
            )
        return "\n".join(lines)

    # ── Add book ───────────────────────────────────────────────────────────
    add_book_match = re.search(
        r"\badd\s+book\b[:\s]+[\"']?(.+?)[\"']?\s+by\s+[\"']?(.+?)[\"']?\s+"
        r"genre[:\s]+[\"']?(.+?)[\"']?\s+year[:\s]+(\d{4})\s+isbn[:\s]+([^\s]+)\s+copies[:\s]+(\d+)",
        lower
    )
    if add_book_match:
        title, author, genre = add_book_match.group(1), add_book_match.group(2), add_book_match.group(3)
        year, isbn, copies   = int(add_book_match.group(4)), add_book_match.group(5), int(add_book_match.group(6))
        # Preserve original casing from the raw message
        raw = text
        title_raw  = re.search(r'add\s+book[:\s]+["\']?(.+?)["\']?\s+by', raw, re.I)
        author_raw = re.search(r'\bby\s+["\']?(.+?)["\']?\s+genre', raw, re.I)
        if title_raw:  title  = title_raw.group(1)
        if author_raw: author = author_raw.group(1)
        ok, msg_out = add_book(title, author, genre.title(), year, isbn, copies)
        return msg_out

    if re.search(r"\badd\s+(a\s+)?book\b", lower):
        return (
            "To add a book, use this format:\n\n"
            "`add book [Title] by [Author] genre [Genre] year [YYYY] isbn [ISBN] copies [N]`\n\n"
            "**Example:**\n"
            "`add book The Midnight Library by Matt Haig genre Fiction year 2020 isbn 978-0525559474 copies 3`"
        )

    # ── Find member ────────────────────────────────────────────────────────
    find_member_match = re.search(
        r"\b(find|search|look up|lookup)\s+member\b\s+(.+)", lower
    )
    if find_member_match:
        query = find_member_match.group(2).strip()
        members = find_member(query)
        if members:
            return f"👤 Found **{len(members)}** member(s):\n\n" + format_member_list(members)
        return f"No members found matching *\"{query}\"*."

    # ── All members ────────────────────────────────────────────────────────
    if re.search(r"\b(all members?|list members?|show members?|every member)\b", lower):
        members = get_all_members()
        return f"👥 **{len(members)} registered members:**\n\n" + format_member_list(members)

    # ── Add member ─────────────────────────────────────────────────────────
    add_member_match = re.search(
        r"\badd\s+member\b[:\s]+[\"']?(.+?)[\"']?\s+(?:email[:\s]+)?([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})",
        text, re.I
    )
    if add_member_match:
        name  = add_member_match.group(1).strip()
        email = add_member_match.group(2).strip()
        ok, msg_out = add_member(name, email)
        return msg_out

    if re.search(r"\badd\s+(a\s+)?member\b", lower):
        return (
            "To register a new member, use:\n\n"
            "`add member [Full Name] [email@example.com]`\n\n"
            "**Example:**\n"
            "`add member Jane Doe jane.doe@example.com`"
        )

    # ── Book detail by ID ──────────────────────────────────────────────────
    book_id_match = re.search(r"\bbook\s+(?:id\s*[:#]?\s*)?(\d+)\b", lower)
    if book_id_match:
        book = get_book_by_id(int(book_id_match.group(1)))
        if book:
            avail = f"✅ {book['available']} of {book['copies']} copies available" if book['available'] > 0 else "❌ All copies checked out"
            return (
                f"📖 **{book['title']}**\n"
                f"✍️ Author: *{book['author']}*\n"
                f"🏷️ Genre: {book['genre']}\n"
                f"📅 Year: {book['year']}\n"
                f"🔖 ISBN: {book['isbn']}\n"
                f"📦 Copies: {avail}\n"
                f"🆔 Book ID: {book['id']}"
            )
        return "Book not found. Please check the ID."

    # ── Farewell ───────────────────────────────────────────────────────────
    if re.search(r"\b(bye|goodbye|see you|take care|farewell|exit|quit)\b", lower):
        return random.choice([
            "Goodbye! Happy reading! 📚",
            "See you next time! Don't forget to return your books on time. 😊",
            "Farewell! The library is always here for you. 📖",
        ])

    # ── Thanks ─────────────────────────────────────────────────────────────
    if re.search(r"\b(thank|thanks|thank you|thx|ty)\b", lower):
        return random.choice([
            "You're welcome! Is there anything else I can help with? 😊",
            "Happy to help! Let me know if you need anything else.",
            "Anytime! The library is here for you. 📚",
        ])

    # ── Genre browsing ─────────────────────────────────────────────────────
    genre_match = re.search(
        r"\b(fantasy|sci-fi|science fiction|thriller|classic|dystopian|fiction|non-fiction|self-help)\b",
        lower
    )
    if genre_match:
        genre = genre_match.group(1)
        genre_map = {"science fiction": "sci-fi"}
        genre = genre_map.get(genre, genre)
        books = search_books(genre)
        if books:
            return f"📚 **{genre.title()} books in our catalog:**\n\n" + format_book_list(books)

    # ── Default ────────────────────────────────────────────────────────────
    return (
        "I'm not sure I understood that. Here are some things you can try:\n\n"
        "• `search [book title or author]`\n"
        "• `available books`\n"
        "• `borrow book 3 member 1`\n"
        "• `return book 3 member 1`\n"
        "• `all members`\n"
        "• `stats`\n"
        "• `overdue`\n\n"
        "Type **help** for the full command list."
    )


# ---------------------------------------------------------------------------
# Flask routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": "No message provided"}), 400
    user_message = data["message"].strip()
    if not user_message:
        return jsonify({"error": "Empty message"}), 400
    response = process_message(user_message)
    return jsonify({"response": response})


@app.route("/api/stats")
def api_stats():
    return jsonify(get_stats())


@app.route("/api/books")
def api_books():
    return jsonify(get_all_books())


@app.route("/api/members")
def api_members():
    return jsonify(get_all_members())


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
