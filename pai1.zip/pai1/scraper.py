import csv
import re
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def selenium_scraper(url_list, output_file="scraped_emails.csv"):
    # 1. Setup Chrome options (Run "headless" if you don't want to see the window)
    chrome_options = Options()
    # chrome_options.add_argument("--headless") # Uncomment this to hide the window
    
    # 2. Initialize the Driver
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    
    email_pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
    found_data = []

    try:
        for url in url_list:
            print(f"🚀 Opening Browser to: {url}")
            driver.get(url)
            
            # Wait 5 seconds for JavaScript to load
            time.sleep(5) 
            
            # Get the page source AFTER JavaScript has executed
            page_source = driver.page_source
            emails = set(re.findall(email_pattern, page_source))
            
            if emails:
                print(f"Found {len(emails)} emails!")
                for e in emails:
                    # Filter out common false positives like 'sentry.io' or image extensions
                    if not e.endswith(('.png', '.jpg', '.jpeg', '.gif')):
                        found_data.append({"URL": url, "Email": e})
            else:
                print(f"No emails visible on {url}")

    finally:
        driver.quit()

    # 3. Save to CSV
    if found_data:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=["URL", "Email"])
            writer.writeheader()
            writer.writerows(found_data)
        print(f"\nDone! Data saved to {output_file}")
    else:
        print("\nStill no luck. The site might be encrypting emails or using images.")

# --- RUN IT ---
urls = ["https://www.hunter.io/contact"] # Use a site that definitely has text emails
selenium_scraper(urls)