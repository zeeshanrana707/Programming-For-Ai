"""
Face Detection Module using OpenCV and Haar Cascades
Detects faces and facial landmarks for feature measurement
No external dependencies required - uses built-in OpenCV models
"""
import cv2
import numpy as np
from typing import List, Tuple, Optional, Dict
import os

class FaceDetector:
    def __init__(self):
        """Initialize face detector with OpenCV Haar Cascades"""
        # Load Haar Cascade classifiers
        cascade_path = cv2.data.haarcascades
        
        self.face_cascade = cv2.CascadeClassifier(
            os.path.join(cascade_path, 'haarcascade_frontalface_default.xml')
        )
        self.eye_cascade = cv2.CascadeClassifier(
            os.path.join(cascade_path, 'haarcascade_eye.xml')
        )
        self.mouth_cascade = cv2.CascadeClassifier(
            os.path.join(cascade_path, 'haarcascade_smile.xml')
        )
        
        if self.face_cascade.empty():
            raise FileNotFoundError("Haar Cascade face detector not found")
    
    def detect_faces(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        Detect faces in the image
        
        Args:
            image: Input image (numpy array)
            
        Returns:
            List of (x, y, w, h) tuples representing detected faces
        """
        # Convert to grayscale if color
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image
        
        # Detect faces with multi-scale detection
        faces = self.face_cascade.detectMultiScale(
            gray, 
            scaleFactor=1.1, 
            minNeighbors=5, 
            minSize=(30, 30),
            maxSize=(400, 400),
            flags=cv2.CASCADE_SCALE_IMAGE
        )
        
        return faces
    
    def detect_landmarks(self, image: np.ndarray, face: Tuple[int, int, int, int]) -> Optional[List[Tuple[int, int]]]:
        """
        Detect facial landmarks for a given face region
        Creates synthetic 68-point landmarks from detected features
        
        Args:
            image: Input image
            face: (x, y, w, h) representing face region
            
        Returns:
            List of (x, y) tuples representing ~68 landmark coordinates
        """
        try:
            x, y, w, h = face
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            
            face_roi = gray[y:y+h, x:x+w]
            
            # Generate synthetic 68 landmarks from detected features
            landmarks = self._generate_landmarks(image, face)
            
            return landmarks if landmarks else None
        except Exception as e:
            print(f"Error detecting landmarks: {e}")
            return None
    
    def _generate_landmarks(self, image: np.ndarray, face: Tuple[int, int, int, int]) -> List[Tuple[int, int]]:
        """
        Generate synthetic 68-point landmarks from face region
        Maps detected eyes and face geometry to approximate DLIB 68-point format
        """
        x, y, w, h = face
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
        face_roi = gray[y:y+h, x:x+w]
        
        landmarks = []
        
        # Jaw line (0-16) - approximate from face contour
        jaw_y_start = y + int(h * 0.3)
        jaw_y_end = y + h
        for i in range(17):
            lx = x + int((i / 17) * w)
            ly = jaw_y_start + int(((i / 17) ** 1.5) * (jaw_y_end - jaw_y_start))
            landmarks.append((lx, ly))
        
        # Eyebrows (17-26)
        left_eyebrow_y = y + int(h * 0.2)
        right_eyebrow_y = y + int(h * 0.2)
        for i in range(5):
            lx = x + int((0.2 + (i / 25) * 0.3) * w)
            landmarks.append((lx, left_eyebrow_y))
        for i in range(5):
            lx = x + int((0.5 + (i / 25) * 0.3) * w)
            landmarks.append((lx, right_eyebrow_y))
        
        # Nose (27-35)
        nose_top_y = y + int(h * 0.25)
        nose_bottom_y = y + int(h * 0.55)
        nose_x = x + int(w * 0.5)
        for i in range(4):
            ly = nose_top_y + int((i / 4) * (nose_bottom_y - nose_top_y))
            landmarks.append((nose_x, ly))
        # Nose base
        landmarks.append((nose_x, nose_bottom_y))
        # Nose wings
        for i in range(4):
            offset = int(w * 0.15 * (1 - (i / 4) ** 2))
            landmarks.append((nose_x - offset, nose_bottom_y - int(i * h * 0.05)))
        
        # Detect eyes
        eyes = self.eye_cascade.detectMultiScale(
            face_roi, 
            scaleFactor=1.1, 
            minNeighbors=4, 
            minSize=(20, 20)
        )
        
        # Left eye (36-41) and Right eye (42-47)
        if len(eyes) >= 2:
            eyes = sorted(eyes, key=lambda e: e[0])
            left_eye = eyes[0]
            right_eye = eyes[1]
            
            # Left eye points
            eye_x, eye_y, eye_w, eye_h = left_eye
            eye_cx = x + eye_x + eye_w // 2
            eye_cy = y + eye_y + eye_h // 2
            for i in range(6):
                angle = (i / 6) * 2 * np.pi
                ex = int(eye_cx + (eye_w * 0.5) * np.cos(angle))
                ey = int(eye_cy + (eye_h * 0.4) * np.sin(angle))
                landmarks.append((ex, ey))
            
            # Right eye points
            eye_x, eye_y, eye_w, eye_h = right_eye
            eye_cx = x + eye_x + eye_w // 2
            eye_cy = y + eye_y + eye_h // 2
            for i in range(6):
                angle = (i / 6) * 2 * np.pi
                ex = int(eye_cx + (eye_w * 0.5) * np.cos(angle))
                ey = int(eye_cy + (eye_h * 0.4) * np.sin(angle))
                landmarks.append((ex, ey))
        else:
            # Approximate eyes if not detected
            eye_y = y + int(h * 0.3)
            for _ in range(12):
                landmarks.append((x + int(w * 0.3), eye_y) if len(landmarks) < 42 else (x + int(w * 0.7), eye_y))
        
        # Mouth (48-67)
        mouth_y = y + int(h * 0.65)
        mouth_x_left = x + int(w * 0.3)
        mouth_x_right = x + int(w * 0.7)
        mouth_x_center = x + int(w * 0.5)
        
        # Outer mouth contour
        for i in range(12):
            if i < 6:
                lx = mouth_x_left + int((i / 6) * (mouth_x_right - mouth_x_left))
            else:
                lx = mouth_x_right - int(((i - 6) / 6) * (mouth_x_right - mouth_x_left))
            ly = mouth_y + int(np.sin((i / 12) * np.pi) * h * 0.05)
            landmarks.append((lx, ly))
        
        # Inner mouth contour
        for i in range(8):
            if i < 4:
                lx = mouth_x_left + int((i / 4) * (mouth_x_right - mouth_x_left))
            else:
                lx = mouth_x_right - int(((i - 4) / 4) * (mouth_x_right - mouth_x_left))
            ly = mouth_y + int(np.sin((i / 8) * np.pi) * h * 0.02)
            landmarks.append((lx, ly))
        
        return landmarks[:68]  # Ensure exactly 68 points
    
    def get_landmark_groups(self, landmarks: List[Tuple[int, int]]) -> Dict[str, List[Tuple[int, int]]]:
        """
        Group landmarks by facial features
        
        Args:
            landmarks: List of 68 landmarks
            
        Returns:
            Dictionary mapping feature names to landmark coordinates
        """
        if not landmarks or len(landmarks) != 68:
            return {}
        
        return {
            'jaw': landmarks[0:17],
            'left_eyebrow': landmarks[17:22],
            'right_eyebrow': landmarks[22:27],
            'nose_bridge': landmarks[27:31],
            'nose_tip': landmarks[31:36],
            'left_eye': landmarks[36:42],
            'right_eye': landmarks[42:48],
            'mouth_outer': landmarks[48:60],
            'mouth_inner': landmarks[60:68]
        }

def draw_landmarks(image: np.ndarray, landmarks: List[Tuple[int, int]], color: Tuple[int, int, int] = (0, 255, 0)) -> np.ndarray:
    """
    Draw landmarks on the image
    
    Args:
        image: Input image
        landmarks: List of landmark coordinates
        color: Color for drawing (BGR format)
        
    Returns:
        Image with landmarks drawn
    """
    output = image.copy()
    for (x, y) in landmarks:
        cv2.circle(output, (x, y), 3, color, -1)
    return output

def draw_landmark_groups(image: np.ndarray, landmark_groups: Dict) -> np.ndarray:
    """
    Draw facial feature regions
    
    Args:
        image: Input image
        landmark_groups: Dictionary of landmark groups
        
    Returns:
        Image with features drawn
    """
    output = image.copy()
    
    colors = {
        'jaw': (255, 0, 0),
        'left_eyebrow': (0, 255, 0),
        'right_eyebrow': (0, 255, 0),
        'nose_bridge': (255, 255, 0),
        'nose_tip': (255, 255, 0),
        'left_eye': (255, 0, 255),
        'right_eye': (255, 0, 255),
        'mouth_outer': (0, 255, 255),
        'mouth_inner': (0, 255, 255)
    }
    
    for feature, landmarks in landmark_groups.items():
        color = colors.get(feature, (200, 200, 200))
        for (x, y) in landmarks:
            cv2.circle(output, (x, y), 2, color, -1)
    
    return output
