"""Utils package for face profiling"""
