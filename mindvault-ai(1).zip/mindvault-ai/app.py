"""
MindVault AI - Main Entry Point

Usage:
    python run.py              # Run the application
    python run.py --help       # Show help
"""
import os
import sys

def main():
    """Main application entry point"""
    
    # Check dependencies
    try:
        from app import create_app, db
    except ImportError as e:
        print(f"\n❌ Error: {e}")
        print("📦 Install dependencies: python install_dependencies.py\n")
        sys.exit(1)
    
    # Create app
    app = create_app()
    
    # Create database tables
    with app.app_context():
        db.create_all()
    
    # Display startup info
    print("\n" + "="*60)
    print("🧠 MindVault AI - Intelligent Document Research Assistant")
    print("="*60)
    print("🌐 Server: http://localhost:5000")
    print("� Test Account: test@mindvault.ai / Test123!")
    print("📚 Documentation: COMPLETE_DOCUMENTATION.md")
    print("="*60 + "\n")
    
    # Run the application
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    except KeyboardInterrupt:
        print("\n\n👋 Shutting down MindVault AI...\n")
        sys.exit(0)

if __name__ == '__main__':
    main()
