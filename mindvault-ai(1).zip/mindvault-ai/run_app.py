"""
Simple launcher that uses the virtual environment automatically
"""
import os
import sys
import subprocess

# Path to virtual environment Python
venv_python = os.path.join('venv', 'Scripts', 'python.exe')

if not os.path.exists(venv_python):
    print("\n❌ Virtual environment not found!")
    print("📦 Run: python install_dependencies.py\n")
    sys.exit(1)

# Run app.py using virtual environment Python
print("🚀 Starting MindVault AI...\n")
subprocess.run([venv_python, 'app.py'])
