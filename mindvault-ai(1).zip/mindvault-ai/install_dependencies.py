"""
MindVault AI - Dependency Installation Script
Installs all required packages into the virtual environment
"""
import subprocess
import sys
import os

def main():
    print("=" * 60)
    print("🧠 MindVault AI - Installing Dependencies")
    print("=" * 60)
    
    # Check if we're in a virtual environment
    venv_path = os.path.join(os.getcwd(), 'venv')
    if not os.path.exists(venv_path):
        print("\n❌ Virtual environment not found!")
        print("📝 Creating virtual environment...")
        subprocess.run([sys.executable, '-m', 'venv', 'venv'], check=True)
        print("✅ Virtual environment created")
    
    # Determine the pip path
    if sys.platform == 'win32':
        pip_path = os.path.join(venv_path, 'Scripts', 'pip.exe')
        python_path = os.path.join(venv_path, 'Scripts', 'python.exe')
    else:
        pip_path = os.path.join(venv_path, 'bin', 'pip')
        python_path = os.path.join(venv_path, 'bin', 'python')
    
    print(f"\n📦 Installing packages from requirements.txt...")
    print(f"Using pip: {pip_path}\n")
    
    try:
        # Upgrade pip first
        subprocess.run([python_path, '-m', 'pip', 'install', '--upgrade', 'pip'], check=True)
        
        # Install requirements
        subprocess.run([pip_path, 'install', '-r', 'requirements.txt'], check=True)
        
        print("\n" + "=" * 60)
        print("✅ All dependencies installed successfully!")
        print("=" * 60)
        print("\n📝 Next steps:")
        print("1. Configure your .env file and add GROQ_API_KEY")
        print("2. Run: python app.py")
        print("\n")
        
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Error installing dependencies: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
