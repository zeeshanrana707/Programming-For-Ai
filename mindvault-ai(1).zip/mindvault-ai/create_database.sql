-- ============================================================
-- MindVault AI - Database Creation Script
-- ============================================================

-- Create the database
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'mindvault_db')
BEGIN
    CREATE DATABASE mindvault_db;
    PRINT '✓ Database "mindvault_db" created successfully!';
END
ELSE
BEGIN
    PRINT '✓ Database "mindvault_db" already exists.';
END
GO

-- Switch to the new database
USE mindvault_db;
GO

-- Verify we're in the correct database
SELECT 
    DB_NAME() AS CurrentDatabase,
    GETDATE() AS CreatedAt;
GO

PRINT '';
PRINT '============================================================';
PRINT 'Database setup complete!';
PRINT '';
PRINT 'Next steps:';
PRINT '1. Update your .env file with the correct DB_SERVER name';
PRINT '2. Run: python quickstart.py (to test connection)';
PRINT '3. Run: python run.py (to create tables and start app)';
PRINT '============================================================';
GO
