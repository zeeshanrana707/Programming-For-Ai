from app import db
from datetime import datetime


class Project(db.Model):
    """Project model for organizing documents and chats"""
    __tablename__ = 'projects'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_archived = db.Column(db.Boolean, default=False)
    
    # Relationships
    documents = db.relationship('Document', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    chats = db.relationship('Chat', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    generated_contents = db.relationship('GeneratedContent', backref='project', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Project {self.name}>'
    
    def to_dict(self):
        """Convert project to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_archived': self.is_archived,
            'document_count': self.documents.count(),
            'chat_count': self.chats.count()
        }
    
    def get_all_chunks(self):
        """Get all document chunks in this project with round-robin mixing for document diversity"""
        from app.models.document import DocumentChunk
        from collections import defaultdict
        
        # Get chunks from each document separately
        doc_chunks = defaultdict(list)
        for doc in self.documents.filter_by(processed=True).all():
            # Order by page within each document
            doc_chunks[doc.id] = doc.chunks.order_by(
                DocumentChunk.page_number,
                DocumentChunk.chunk_index
            ).all()
        
        # Interleave chunks from different documents (round-robin)
        chunks = []
        max_chunks_per_doc = max(len(c) for c in doc_chunks.values()) if doc_chunks else 0
        
        for i in range(max_chunks_per_doc):
            for doc_id in sorted(doc_chunks.keys()):
                if i < len(doc_chunks[doc_id]):
                    chunks.append(doc_chunks[doc_id][i])
        
        return chunks
