from app import db
from datetime import datetime
import json


class Document(db.Model):
    """Document model for uploaded PDFs/DOCX files"""
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    original_path = db.Column(db.String(500))
    file_size = db.Column(db.BigInteger)
    file_type = db.Column(db.String(50))  # pdf, docx, txt
    total_pages = db.Column(db.Integer)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    processed = db.Column(db.Boolean, default=False)
    processing_status = db.Column(db.String(50), default='pending')  # pending, processing, completed, failed
    extracted_text = db.Column(db.Text)
    doc_metadata = db.Column(db.Text)  # JSON string - renamed from metadata to avoid SQLAlchemy conflict
    
    # Relationships
    chunks = db.relationship('DocumentChunk', backref='document', lazy='dynamic', cascade='all, delete-orphan')
    citations = db.relationship('Citation', backref='document', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Document {self.filename}>'
    
    def set_metadata(self, metadata_dict):
        """Store metadata as JSON string"""
        self.doc_metadata = json.dumps(metadata_dict)
    
    def get_metadata(self):
        """Retrieve metadata as dictionary"""
        if self.doc_metadata:
            return json.loads(self.doc_metadata)
        return {}
    
    def to_dict(self):
        """Convert document to dictionary"""
        return {
            'id': self.id,
            'filename': self.filename,
            'file_size': self.file_size,
            'file_type': self.file_type,
            'total_pages': self.total_pages,
            'upload_date': self.upload_date.isoformat() if self.upload_date else None,
            'processed': self.processed,
            'processing_status': self.processing_status,
            'metadata': self.get_metadata(),
            'chunk_count': self.chunks.count()
        }


class DocumentChunk(db.Model):
    """Document chunks for RAG retrieval"""
    __tablename__ = 'document_chunks'
    
    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id', ondelete='CASCADE'), nullable=False)
    chunk_text = db.Column(db.Text, nullable=False)
    chunk_index = db.Column(db.Integer)
    page_number = db.Column(db.Integer)
    start_char = db.Column(db.Integer)
    end_char = db.Column(db.Integer)
    
    # Indexes for faster queries
    __table_args__ = (
        db.Index('idx_document_id', 'document_id'),
        db.Index('idx_page_number', 'page_number'),
    )
    
    def __repr__(self):
        return f'<DocumentChunk {self.id} - Page {self.page_number}>'
    
    def to_dict(self):
        """Convert chunk to dictionary"""
        return {
            'id': self.id,
            'document_id': self.document_id,
            'chunk_text': self.chunk_text,
            'chunk_index': self.chunk_index,
            'page_number': self.page_number,
            'document_name': self.document.filename if self.document else None
        }
