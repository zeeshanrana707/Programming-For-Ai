from app import db
from datetime import datetime
import json


class GeneratedContent(db.Model):
    """Generated PDFs (notes, quizzes, summaries)"""
    __tablename__ = 'generated_content'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    content_type = db.Column(db.String(50), nullable=False)  # notes, quiz, summary, analysis
    title = db.Column(db.String(255))
    content = db.Column(db.Text)  # Text content before PDF generation
    pdf_path = db.Column(db.String(500))  # Path to generated PDF
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    source_documents = db.Column(db.Text)  # JSON array of document IDs
    page_count = db.Column(db.Integer)
    file_size = db.Column(db.BigInteger)
    
    # Indexes
    __table_args__ = (
        db.Index('idx_project_id', 'project_id'),
        db.Index('idx_content_type', 'content_type'),
    )
    
    def __repr__(self):
        return f'<GeneratedContent {self.content_type} - {self.title}>'
    
    def set_source_documents(self, doc_ids):
        """Store source document IDs as JSON"""
        self.source_documents = json.dumps(doc_ids)
    
    def get_source_documents(self):
        """Retrieve source document IDs"""
        if self.source_documents:
            return json.loads(self.source_documents)
        return []
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'content_type': self.content_type,
            'title': self.title,
            'pdf_path': self.pdf_path,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'source_documents': self.get_source_documents(),
            'page_count': self.page_count,
            'file_size': self.file_size
        }
