from app import db
from datetime import datetime


class Chat(db.Model):
    """Chat conversation threads"""
    __tablename__ = 'chats'
    
    id = db.Column(db.Integer, primary_key=True)
    project_id = db.Column(db.Integer, db.ForeignKey('projects.id', ondelete='CASCADE'), nullable=False)
    title = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_pinned = db.Column(db.Boolean, default=False)
    
    # Relationships
    messages = db.relationship('Message', backref='chat', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Chat {self.title}>'
    
    def generate_title(self):
        """Generate title from first user message"""
        first_message = self.messages.filter_by(role='user').first()
        if first_message:
            # Take first 50 characters
            self.title = first_message.content[:50] + ('...' if len(first_message.content) > 50 else '')
        else:
            self.title = f'Chat {self.id}'
    
    def to_dict(self):
        """Convert chat to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_pinned': self.is_pinned,
            'message_count': self.messages.count()
        }


class Message(db.Model):
    """Chat messages with role (user/assistant)"""
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chats.id', ondelete='CASCADE'), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # user, assistant
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    tokens_used = db.Column(db.Integer)
    has_citations = db.Column(db.Boolean, default=False)
    
    # Relationships
    citations = db.relationship('Citation', backref='message', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Message {self.role} - {self.id}>'
    
    def to_dict(self):
        """Convert message to dictionary"""
        return {
            'id': self.id,
            'role': self.role,
            'content': self.content,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'tokens_used': self.tokens_used,
            'has_citations': self.has_citations,
            'citations': [c.to_dict() for c in self.citations.all()] if self.has_citations else []
        }


class Citation(db.Model):
    """Source citations for AI responses"""
    __tablename__ = 'citations'
    
    id = db.Column(db.Integer, primary_key=True)
    message_id = db.Column(db.Integer, db.ForeignKey('messages.id', ondelete='CASCADE'), nullable=False)
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id', ondelete='NO ACTION'), nullable=False)
    chunk_id = db.Column(db.Integer, db.ForeignKey('document_chunks.id', ondelete='NO ACTION'))
    page_number = db.Column(db.Integer)
    quoted_text = db.Column(db.Text)
    relevance_score = db.Column(db.Float)
    
    def __repr__(self):
        return f'<Citation {self.document.filename} - Page {self.page_number}>'
    
    def to_dict(self):
        """Convert citation to dictionary"""
        return {
            'id': self.id,
            'document_id': self.document_id,
            'document_name': self.document.filename if self.document else None,
            'page_number': self.page_number,
            'quoted_text': self.quoted_text,
            'relevance_score': self.relevance_score
        }
