from flask import current_app, url_for, render_template_string
from flask_mail import Message
from app import mail


class EmailService:
    """Service for sending emails"""
    
    @staticmethod
    def send_verification_email(user):
        """Send email verification link"""
        token = user.verification_token
        verify_url = url_for('auth.verify_email', token=token, _external=True)
        
        subject = "Verify Your MindVault AI Account"
        
        html_body = f"""
        <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h2 style="color: #2563eb;">Welcome to MindVault AI! 🧠</h2>
                <p>Hi {user.username},</p>
                <p>Thank you for signing up! Please verify your email address by clicking the button below:</p>
                <p style="margin: 30px 0;">
                    <a href="{verify_url}" 
                       style="background-color: #2563eb; color: white; padding: 12px 24px; 
                              text-decoration: none; border-radius: 6px; display: inline-block;">
                        Verify Email Address
                    </a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p style="color: #666; word-break: break-all;">{verify_url}</p>
                <p style="margin-top: 30px; color: #666; font-size: 12px;">
                    If you didn't create this account, please ignore this email.
                </p>
            </body>
        </html>
        """
        
        text_body = f"""
        Welcome to MindVault AI!
        
        Hi {user.username},
        
        Thank you for signing up! Please verify your email address by visiting:
        {verify_url}
        
        If you didn't create this account, please ignore this email.
        """
        
        return EmailService._send_email(
            subject=subject,
            recipients=[user.email],
            text_body=text_body,
            html_body=html_body
        )
    
    @staticmethod
    def send_password_reset_email(user):
        """Send password reset link"""
        token = user.reset_token
        reset_url = url_for('auth.reset_password', token=token, _external=True)
        
        subject = "Reset Your MindVault AI Password"
        
        html_body = f"""
        <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h2 style="color: #2563eb;">Password Reset Request</h2>
                <p>Hi {user.username},</p>
                <p>We received a request to reset your password. Click the button below to create a new password:</p>
                <p style="margin: 30px 0;">
                    <a href="{reset_url}" 
                       style="background-color: #2563eb; color: white; padding: 12px 24px; 
                              text-decoration: none; border-radius: 6px; display: inline-block;">
                        Reset Password
                    </a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p style="color: #666; word-break: break-all;">{reset_url}</p>
                <p style="margin-top: 30px; color: #666;">
                    This link will expire in 24 hours.
                </p>
                <p style="color: #666; font-size: 12px;">
                    If you didn't request a password reset, please ignore this email.
                </p>
            </body>
        </html>
        """
        
        text_body = f"""
        Password Reset Request
        
        Hi {user.username},
        
        We received a request to reset your password. Visit this link to create a new password:
        {reset_url}
        
        This link will expire in 24 hours.
        
        If you didn't request a password reset, please ignore this email.
        """
        
        return EmailService._send_email(
            subject=subject,
            recipients=[user.email],
            text_body=text_body,
            html_body=html_body
        )
    
    @staticmethod
    def send_welcome_email(user):
        """Send welcome email after verification"""
        subject = "Welcome to MindVault AI! 🎉"
        
        html_body = f"""
        <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h2 style="color: #2563eb;">Welcome to MindVault AI! 🎉</h2>
                <p>Hi {user.username},</p>
                <p>Your email has been verified successfully!</p>
                <p>You can now:</p>
                <ul>
                    <li>📚 Upload PDFs and documents</li>
                    <li>💬 Chat with your documents using AI</li>
                    <li>📝 Generate study notes</li>
                    <li>🧠 Create quizzes</li>
                    <li>📊 Get summaries and analysis</li>
                </ul>
                <p style="margin-top: 30px;">
                    <a href="{url_for('dashboard.home', _external=True)}" 
                       style="background-color: #2563eb; color: white; padding: 12px 24px; 
                              text-decoration: none; border-radius: 6px; display: inline-block;">
                        Go to Dashboard
                    </a>
                </p>
                <p style="margin-top: 30px; color: #666;">
                    Happy researching! 🚀
                </p>
            </body>
        </html>
        """
        
        text_body = f"""
        Welcome to MindVault AI!
        
        Hi {user.username},
        
        Your email has been verified successfully!
        
        You can now:
        - Upload PDFs and documents
        - Chat with your documents using AI
        - Generate study notes
        - Create quizzes
        - Get summaries and analysis
        
        Happy researching!
        """
        
        return EmailService._send_email(
            subject=subject,
            recipients=[user.email],
            text_body=text_body,
            html_body=html_body
        )
    
    @staticmethod
    def _send_email(subject, recipients, text_body, html_body):
        """Internal method to send email"""
        try:
            msg = Message(
                subject=subject,
                recipients=recipients,
                body=text_body,
                html=html_body
            )
            mail.send(msg)
            return True
        except Exception as e:
            print(f"Error sending email: {e}")
            return False
