from groq import Groq
from flask import current_app
import re


class AIService:
    """Service for AI operations using Groq API"""
    
    def __init__(self):
        self.client = Groq(api_key=current_app.config['GROQ_API_KEY'])
        self.model = current_app.config['AI_MODEL']
    
    def chat_with_web_search(self, query, chunks):
        """Generate AI response with both document context and general knowledge"""
        doc_context = self._build_context(chunks[:30]) if chunks else ""  # Increased from 20 to 30
        
        # Extract unique document names
        doc_names = set()
        for chunk in chunks[:30]:
            if chunk.document:
                doc_names.add(chunk.document.filename)
        
        doc_list = ", ".join(sorted(doc_names)) if doc_names else "documents"
        
        prompt = f"""You are an intelligent research assistant with access to both documents and general knowledge.

User Question: {query}

{"Document Context from MULTIPLE DOCUMENTS (" + doc_list + "):\n" + doc_context if doc_context else "No documents available."}

Instructions:
- Answer the question using BOTH the provided documents AND your general knowledge
- If the question is about the documents, cite ALL relevant documents specifically
- If the question requires general knowledge or current information, provide that freely
- Be comprehensive and helpful
- Provide detailed, well-structured answers
- Use information from ALL documents and ALL pages, not just one document or the first page
- When multiple documents are available, synthesize information from all of them

Answer:"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2048
            )
            
            answer = response.choices[0].message.content
            used_chunks = self._identify_used_chunks(answer, chunks) if chunks else []
            return answer, used_chunks
                
        except Exception as e:
            print(f"AI Service Error: {e}")
            return "I'm sorry, I encountered an error processing your request.", []
    
    def chat_with_context(self, query, chunks, language='en'):
        """Generate AI response with context from document chunks"""
        context_text = self._build_context(chunks[:30])  # Increased from default to 30
        
        # Extract unique document names
        doc_names = set()
        for chunk in chunks[:30]:
            if chunk.document:
                doc_names.add(chunk.document.filename)
        
        doc_list = ", ".join(sorted(doc_names)) if doc_names else "documents"
        
        if language == 'ur':
            system_prompt = """آپ ایک ذہین تحقیقی معاون ہیں۔ صارف کے سوال کا جواب صرف فراہم کردہ دستاویزات کے سیاق و سباق کی بنیاد پر دیں۔"""
            prompt = f"""{system_prompt}

دستاویزات سے سیاق و سباق:
{context_text}

صارف کا سوال: {query}

جواب:"""
        else:
            prompt = f"""You are an intelligent research assistant. Answer the user's question using the provided context from MULTIPLE DOCUMENTS: {doc_list}

Context from multiple documents:
{context_text}

User Question: {query}

Instructions:
- Answer based on the provided context from ALL documents and ALL pages
- If the answer is not in the context, say "I don't have enough information"
- Be specific and cite information accurately from ALL different documents
- Use clear, concise language
- Synthesize information from multiple documents and pages when relevant
- When listing or describing content, include information from ALL documents, not just one

Answer:"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=1024
            )
            
            answer = response.choices[0].message.content
            used_chunks = self._identify_used_chunks(answer, chunks)
            return answer, used_chunks
                
        except Exception as e:
            print(f"AI Service Error: {e}")
            return "I'm sorry, I encountered an error processing your request.", []
    
    def generate_notes(self, chunks):
        """Generate structured study notes from document chunks"""
        context = self._build_context(chunks[:40])  # Increased from 20 to 40 for more comprehensive notes
        
        # Extract unique document names from chunks
        doc_names = set()
        for chunk in chunks[:40]:
            if chunk.document:
                doc_names.add(chunk.document.filename)
        
        doc_list = ", ".join(sorted(doc_names)) if doc_names else "the provided documents"
        
        prompt = f"""Create comprehensive study notes from the following content from MULTIPLE DOCUMENTS: {doc_list}

Content from multiple documents:
{context}

IMPORTANT INSTRUCTIONS:
- Create separate sections for EACH DIFFERENT DOCUMENT/TOPIC you find in the content
- Identify all distinct topics and documents in the provided content
- Do NOT focus on just one document - cover ALL documents equally
- Use clear headings to separate different documents/topics
- For each document/topic, provide:
  * Clear headings and subheadings
  * Bullet points for key concepts
  * Important definitions
  * Examples where applicable
  * Summary of main points

Study Notes (covering ALL documents):"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.5,
                max_tokens=3000  # Increased from 2048 for longer notes
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating notes: {e}")
            return "Error generating notes"
    
    def generate_quiz(self, chunks, num_questions=10):
        """Generate quiz questions from document chunks"""
        context = self._build_context(chunks[:25])  # Increased to cover more documents
        
        # Extract unique document names
        doc_names = set()
        for chunk in chunks[:25]:
            if chunk.document:
                doc_names.add(chunk.document.filename)
        
        doc_list = ", ".join(sorted(doc_names)) if doc_names else "the provided documents"
        
        prompt = f"""Create {num_questions} multiple-choice questions based on content from MULTIPLE DOCUMENTS: {doc_list}

Content from multiple documents:
{context}

IMPORTANT: Create questions that cover ALL different documents/topics in the content, not just one document.
Distribute questions across all documents evenly.

For each question, provide:
- Question text
- 4 options (A, B, C, D)
- Correct answer
- Brief explanation

Format:
Q1: [Question]
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
Correct Answer: [Letter]
Explanation: [Brief explanation]

Questions:"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=2048
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating quiz: {e}")
            return "Error generating quiz"
    
    def generate_single_mcq(self, chunks, question_number, previous_questions=None):
        """Generate a single MCQ question"""
        context = self._build_context(chunks[:25])  # Increased from 15 to 25 for more variety
        
        # Extract unique document names
        doc_names = set()
        for chunk in chunks[:25]:
            if chunk.document:
                doc_names.add(chunk.document.filename)
        
        doc_list = ", ".join(sorted(doc_names)) if doc_names else "the provided documents"
        
        previous_q = ""
        if previous_questions:
            previous_q = f"\n\nPreviously asked questions (don't repeat):\n{previous_questions}"
        
        prompt = f"""Create ONE multiple-choice question (Question #{question_number}) based on content from MULTIPLE DOCUMENTS: {doc_list}

Content from multiple documents:
{context}{previous_q}

IMPORTANT: Rotate between different documents/topics to ensure variety. Don't focus on just one document.

Create a challenging and educational question. Use content from different pages to create variety. Provide:
- Question text
- 4 options (A, B, C, D)
- Correct answer (just the letter)
- Brief explanation

Format your response EXACTLY like this:
QUESTION: [Your question here]
A) [Option A]
B) [Option B]
C) [Option C]
D) [Option D]
CORRECT: [A/B/C/D]
EXPLANATION: [Brief explanation]

Generate the question:"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.8,
                max_tokens=512
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error generating MCQ: {e}")
            return None
    
    def check_mcq_answer(self, question_data, user_answer):
        """Check if the user's answer is correct and provide feedback"""
        try:
            # Extract correct answer from question_data
            correct_match = re.search(r'CORRECT:\s*([A-D])', question_data, re.IGNORECASE)
            if not correct_match:
                return False, "Unable to verify answer"
            
            correct_answer = correct_match.group(1).upper()
            user_answer = user_answer.upper()
            
            is_correct = (user_answer == correct_answer)
            
            # Extract explanation
            explanation_match = re.search(r'EXPLANATION:\s*(.+)', question_data, re.IGNORECASE | re.DOTALL)
            explanation = explanation_match.group(1).strip() if explanation_match else "No explanation available"
            
            return is_correct, explanation, correct_answer
        except Exception as e:
            print(f"Error checking answer: {e}")
            return False, "Error checking answer", "?"
    
    def _build_context(self, chunks):
        """Build context string from chunks with source tracking - ensures page diversity"""
        # Chunks are now ordered by page_number, so we can take them sequentially
        # and they'll naturally provide page diversity
        
        context_parts = []
        total_chars = 0
        max_chars = 24000
        max_chunks = 30
        
        # Track pages we've seen to ensure diversity
        pages_seen = set()
        selected_chunks = []
        
        # First pass: select chunks from different pages
        for chunk in chunks[:200]:  # Look at first 200 chunks (now ordered by page)
            if len(selected_chunks) >= max_chunks:
                break
            
            # Prefer chunks from pages we haven't seen yet
            if chunk.page_number not in pages_seen:
                selected_chunks.append(chunk)
                pages_seen.add(chunk.page_number)
            elif len(selected_chunks) < max_chunks // 2:
                # If we haven't filled half our quota, skip duplicates
                continue
            else:
                # After half quota, allow some repetition for important pages
                selected_chunks.append(chunk)
        
        # Build context from selected chunks
        for i, chunk in enumerate(selected_chunks, 1):
            doc_name = chunk.document.filename if chunk.document else "Unknown"
            page = chunk.page_number if chunk.page_number else "?"
            chunk_text = chunk.chunk_text[:1000]
            
            context_part = f"[Source {i}: {doc_name}, Page {page}]\n{chunk_text}\n"
            
            if total_chars + len(context_part) > max_chars:
                break
                
            context_parts.append(context_part)
            total_chars += len(context_part)
            
        return "\n".join(context_parts)
    
    def _identify_used_chunks(self, answer, chunks):
        """Identify which chunks were likely used in the answer"""
        used_chunks = []
        answer_words = set(answer.lower().split())
        
        for chunk in chunks:
            chunk_words = set(chunk.chunk_text.lower().split())
            overlap = len(answer_words & chunk_words)
            if overlap > 5:
                used_chunks.append(chunk)
        
        return used_chunks[:5]
