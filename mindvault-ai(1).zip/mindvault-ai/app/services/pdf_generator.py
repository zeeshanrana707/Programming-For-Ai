from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from datetime import datetime
import os
import html
from flask import current_app


class PDFGenerator:
    """Service for generating PDF documents"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#2563eb'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        )
        
        # Heading style
        self.heading_style = ParagraphStyle(
            'CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#1e40af'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        )
        
        # Subheading style
        self.subheading_style = ParagraphStyle(
            'CustomSubheading',
            parent=self.styles['Heading3'],
            fontSize=13,
            textColor=colors.HexColor('#3b82f6'),
            spaceAfter=8,
            spaceBefore=8,
            fontName='Helvetica-Bold'
        )
        
        # Normal text style
        self.normal_style = ParagraphStyle(
            'CustomNormal',
            parent=self.styles['Normal'],
            fontSize=11,
            spaceAfter=6,
            leading=14
        )
        
        # Citation style
        self.citation_style = ParagraphStyle(
            'Citation',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#6b7280'),
            leftIndent=20,
            spaceAfter=4
        )
    
    def generate_notes_pdf(self, project_id, user_id, content, citations, title=None):
        """Generate study notes PDF"""
        # Create filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"notes_{timestamp}.pdf"
        
        # Create directory path
        output_dir = os.path.join(
            current_app.config['GENERATED_FOLDER'],
            str(user_id),
            str(project_id),
            'notes'
        )
        os.makedirs(output_dir, exist_ok=True)
        
        filepath = os.path.join(output_dir, filename)
        
        # Create PDF
        doc = SimpleDocTemplate(filepath, pagesize=letter)
        story = []
        
        # Title
        if not title:
            title = f"Study Notes - {datetime.now().strftime('%B %d, %Y')}"
        story.append(Paragraph(f"📚 {html.escape(title)}", self.title_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Content
        story.extend(self._format_content(content))
        
        # Citations section
        if citations:
            story.append(PageBreak())
            story.append(Paragraph("📖 References", self.heading_style))
            story.append(Spacer(1, 0.2*inch))
            
            for i, citation in enumerate(citations, 1):
                citation_text = f"[{i}] {citation['document_name']}, Page {citation['page_number']}"
                story.append(Paragraph(citation_text, self.citation_style))
        
        # Build PDF
        doc.build(story)
        return filepath
    
    def generate_quiz_pdf(self, project_id, user_id, quiz_content, title=None):
        """Generate quiz PDF"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"quiz_{timestamp}.pdf"
        
        output_dir = os.path.join(
            current_app.config['GENERATED_FOLDER'],
            str(user_id),
            str(project_id),
            'quizzes'
        )
        os.makedirs(output_dir, exist_ok=True)
        
        filepath = os.path.join(output_dir, filename)
        
        doc = SimpleDocTemplate(filepath, pagesize=letter)
        story = []
        
        # Title
        if not title:
            title = f"Quiz - {datetime.now().strftime('%B %d, %Y')}"
        story.append(Paragraph(f"🧠 {html.escape(title)}", self.title_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Quiz content
        story.extend(self._format_content(quiz_content))
        
        # Build PDF
        doc.build(story)
        return filepath
    
    def generate_summary_pdf(self, project_id, user_id, summary_content, citations, title=None):
        """Generate summary PDF"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"summary_{timestamp}.pdf"
        
        output_dir = os.path.join(
            current_app.config['GENERATED_FOLDER'],
            str(user_id),
            str(project_id),
            'summaries'
        )
        os.makedirs(output_dir, exist_ok=True)
        
        filepath = os.path.join(output_dir, filename)
        
        doc = SimpleDocTemplate(filepath, pagesize=letter)
        story = []
        
        # Title
        if not title:
            title = f"Summary - {datetime.now().strftime('%B %d, %Y')}"
        story.append(Paragraph(f"📊 {html.escape(title)}", self.title_style))
        story.append(Spacer(1, 0.3*inch))
        
        # Summary content
        story.extend(self._format_content(summary_content))
        
        # Citations
        if citations:
            story.append(PageBreak())
            story.append(Paragraph("📖 Sources", self.heading_style))
            story.append(Spacer(1, 0.2*inch))
            
            for i, citation in enumerate(citations, 1):
                citation_text = f"[{i}] {citation['document_name']}, Page {citation['page_number']}"
                story.append(Paragraph(citation_text, self.citation_style))
        
        doc.build(story)
        return filepath
    
    def _format_content(self, content):
        """Format content text into PDF elements"""
        story = []
        lines = content.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.1*inch))
                continue
            
            # Detect headings (lines starting with #)
            if line.startswith('###'):
                text = line.replace('###', '').strip()
                story.append(Paragraph(html.escape(text), self.subheading_style))
            elif line.startswith('##'):
                text = line.replace('##', '').strip()
                story.append(Paragraph(html.escape(text), self.heading_style))
            elif line.startswith('#'):
                text = line.replace('#', '').strip()
                story.append(Paragraph(html.escape(text), self.title_style))
            # Bullet points
            elif line.startswith('- ') or line.startswith('• '):
                text = line[2:].strip()
                story.append(Paragraph(f"• {html.escape(text)}", self.normal_style))
            # Numbered lists
            elif line[0].isdigit() and '. ' in line:
                story.append(Paragraph(html.escape(line), self.normal_style))
            # Normal text
            else:
                story.append(Paragraph(html.escape(line), self.normal_style))
        
        return story
