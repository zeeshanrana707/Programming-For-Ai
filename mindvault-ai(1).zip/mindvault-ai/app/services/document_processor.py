from pypdf import PdfReader
import docx
import os
from app import db
from app.models.document import Document, DocumentChunk
from app.utils.text_processing import split_text_into_chunks, clean_text
from flask import current_app


class DocumentProcessor:
    """Service for processing uploaded documents"""
    
    def process_document(self, file, project_id, user_id):
        """
        Process uploaded document (PDF or DOCX)
        
        Args:
            file: Uploaded file object
            project_id: Project ID
            user_id: User ID
        
        Returns:
            Document object
        """
        filename = file.filename
        file_type = filename.rsplit('.', 1)[1].lower()
        
        # Create user/project folder structure
        upload_path = os.path.join(
            current_app.config['UPLOAD_FOLDER'],
            str(user_id),
            str(project_id)
        )
        os.makedirs(upload_path, exist_ok=True)
        
        # Save file with absolute path
        file_path = os.path.abspath(os.path.join(upload_path, filename))
        file.save(file_path)
        
        # Get file size
        file_size = os.path.getsize(file_path)
        
        # Create document record
        document = Document(
            project_id=project_id,
            filename=filename,
            original_path=file_path,  # Store absolute path
            file_size=file_size,
            file_type=file_type,
            processing_status='processing'
        )
        db.session.add(document)
        db.session.commit()
        
        try:
            # Extract text based on file type
            if file_type == 'pdf':
                text, total_pages, metadata = self._process_pdf(file_path)
            elif file_type == 'docx':
                text, total_pages, metadata = self._process_docx(file_path)
            elif file_type == 'txt':
                text, total_pages, metadata = self._process_txt(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            # Update document
            document.extracted_text = text
            document.total_pages = total_pages
            document.set_metadata(metadata)
            document.processed = True
            document.processing_status = 'completed'
            
            # Create chunks
            self._create_chunks(document, text)
            
            db.session.commit()
            return document
            
        except Exception as e:
            print(f"Error processing document: {e}")
            document.processing_status = 'failed'
            db.session.commit()
            raise e
    
    def _process_pdf(self, file_path):
        """Extract text from PDF with page tracking using pdfplumber for better extraction"""
        import pdfplumber
        
        try:
            # Use pdfplumber for better text extraction
            with pdfplumber.open(file_path) as pdf:
                total_pages = len(pdf.pages)
                
                # Extract metadata
                metadata = {
                    'author': pdf.metadata.get('Author', '') if pdf.metadata else '',
                    'title': pdf.metadata.get('Title', '') if pdf.metadata else '',
                    'pages': total_pages
                }
                
                # Extract text page by page
                full_text = ""
                for page_num, page in enumerate(pdf.pages, 1):
                    page_text = page.extract_text()
                    if page_text:
                        full_text += f"\n[PAGE {page_num}]\n{page_text}"
                
                full_text = clean_text(full_text)
                return full_text, total_pages, metadata
                
        except Exception as e:
            print(f"pdfplumber failed, falling back to pypdf: {e}")
            # Fallback to pypdf if pdfplumber fails
            reader = PdfReader(file_path)
            total_pages = len(reader.pages)
            
            metadata = {
                'author': reader.metadata.get('/Author', '') if reader.metadata else '',
                'title': reader.metadata.get('/Title', '') if reader.metadata else '',
                'pages': total_pages
            }
            
            full_text = ""
            for page_num, page in enumerate(reader.pages, 1):
                page_text = page.extract_text()
                if page_text:
                    full_text += f"\n[PAGE {page_num}]\n{page_text}"
            
            full_text = clean_text(full_text)
            return full_text, total_pages, metadata
    
    def _process_docx(self, file_path):
        """Extract text from DOCX"""
        doc = docx.Document(file_path)
        
        # Extract text
        full_text = "\n".join([para.text for para in doc.paragraphs])
        full_text = clean_text(full_text)
        
        # Estimate pages (rough estimate: 500 words per page)
        word_count = len(full_text.split())
        total_pages = max(1, word_count // 500)
        
        metadata = {
            'word_count': word_count,
            'estimated_pages': total_pages
        }
        
        return full_text, total_pages, metadata
    
    def _process_txt(self, file_path):
        """Extract text from TXT file"""
        with open(file_path, 'r', encoding='utf-8') as f:
            full_text = f.read()
        
        full_text = clean_text(full_text)
        
        # Estimate pages
        word_count = len(full_text.split())
        total_pages = max(1, word_count // 500)
        
        metadata = {
            'word_count': word_count,
            'estimated_pages': total_pages
        }
        
        return full_text, total_pages, metadata
    
    def _create_chunks(self, document, text):
        """Create searchable chunks from document text with proper page tracking"""
        import re
        
        # First, split text by page markers to track pages accurately
        page_pattern = r'\[PAGE (\d+)\]'
        
        # Check if text has page markers (PDF files)
        if '[PAGE' in text:
            page_sections = re.split(page_pattern, text)
            
            # page_sections will be: ['', '1', 'text from page 1', '2', 'text from page 2', ...]
            # Every odd index is a page number, every even index (after 0) is the text
            
            all_chunks = []
            chunk_index = 0
            
            for i in range(1, len(page_sections), 2):
                if i + 1 >= len(page_sections):
                    break
                    
                page_num = int(page_sections[i])
                page_text = page_sections[i + 1].strip()
                
                if not page_text:
                    continue
                
                # Split this page's text into chunks
                page_chunks = split_text_into_chunks(page_text, chunk_size=500, overlap=50)
                
                # Create chunk records for this page
                for chunk_text in page_chunks:
                    chunk = DocumentChunk(
                        document_id=document.id,
                        chunk_text=chunk_text,
                        chunk_index=chunk_index,
                        page_number=page_num,
                        start_char=chunk_index * 450,
                        end_char=(chunk_index + 1) * 450
                    )
                    db.session.add(chunk)
                    chunk_index += 1
        else:
            # No page markers (DOCX, TXT files) - treat as single page or estimate pages
            chunks = split_text_into_chunks(text, chunk_size=500, overlap=50)
            
            # Estimate page number based on character position
            # Assuming ~2000 characters per page
            chars_per_page = 2000
            
            for idx, chunk_text in enumerate(chunks):
                # Estimate page number based on chunk position
                estimated_page = (idx * 450) // chars_per_page + 1
                estimated_page = min(estimated_page, document.total_pages or 1)
                
                chunk = DocumentChunk(
                    document_id=document.id,
                    chunk_text=chunk_text,
                    chunk_index=idx,
                    page_number=estimated_page,
                    start_char=idx * 450,
                    end_char=(idx + 1) * 450
                )
                db.session.add(chunk)
        
        db.session.commit()
    
    def delete_document(self, document_id):
        """Delete document and associated files"""
        document = Document.query.get(document_id)
        if not document:
            return False
        
        # Delete physical file
        if document.original_path and os.path.exists(document.original_path):
            try:
                os.remove(document.original_path)
            except Exception as e:
                print(f"Error deleting file: {e}")
        
        # Delete database record (cascades to chunks)
        db.session.delete(document)
        db.session.commit()
        return True
