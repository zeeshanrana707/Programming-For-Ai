import re


def split_text_into_chunks(text, chunk_size=500, overlap=50):
    """
    Split text into overlapping chunks for better context preservation
    
    Args:
        text: Text to split
        chunk_size: Maximum characters per chunk
        overlap: Number of characters to overlap between chunks
    
    Returns:
        List of text chunks
    """
    # Split by sentences
    sentences = re.split(r'(?<=[.!?])\s+', text)
    
    chunks = []
    current_chunk = ""
    
    for sentence in sentences:
        # If adding this sentence exceeds chunk_size, save current chunk
        if len(current_chunk) + len(sentence) > chunk_size and current_chunk:
            chunks.append(current_chunk.strip())
            # Start new chunk with overlap from previous chunk
            words = current_chunk.split()
            overlap_text = ' '.join(words[-overlap:]) if len(words) > overlap else current_chunk
            current_chunk = overlap_text + " " + sentence
        else:
            current_chunk += " " + sentence
    
    # Add the last chunk
    if current_chunk.strip():
        chunks.append(current_chunk.strip())
    
    return chunks


def extract_page_text(pdf_reader, page_num):
    """
    Extract text from a specific PDF page
    
    Args:
        pdf_reader: PyPDF reader object
        page_num: Page number (0-indexed)
    
    Returns:
        Extracted text
    """
    try:
        page = pdf_reader.pages[page_num]
        text = page.extract_text()
        return text if text else ""
    except Exception as e:
        print(f"Error extracting page {page_num}: {e}")
        return ""


def clean_text(text):
    """
    Clean extracted text
    - Remove extra whitespace
    - Fix common OCR errors
    - Normalize line breaks
    - Preserve Unicode characters (including Urdu/Arabic)
    """
    if not text:
        return ""
    
    # Remove only null bytes and dangerous control characters (preserve Unicode)
    text = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f]', '', text)
    
    # Replace multiple spaces with single space
    text = re.sub(r' +', ' ', text)
    
    # Replace multiple newlines with double newline
    text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
    
    # Remove leading/trailing whitespace from each line
    text = '\n'.join(line.strip() for line in text.split('\n'))
    
    # Fix common OCR/encoding issues (only for English ligatures)
    replacements = {
        'ﬁ': 'fi',
        'ﬂ': 'fl',
        'ﬀ': 'ff',
        'ﬃ': 'ffi',
        'ﬄ': 'ffl',
    }
    
    for old, new in replacements.items():
        text = text.replace(old, new)
    
    return text.strip()


def highlight_text(text, query):
    """
    Highlight search query in text
    
    Args:
        text: Text to search in
        query: Search query
    
    Returns:
        Text with highlighted matches
    """
    if not query:
        return text
    
    # Case-insensitive search
    pattern = re.compile(re.escape(query), re.IGNORECASE)
    return pattern.sub(lambda m: f'<mark>{m.group()}</mark>', text)
