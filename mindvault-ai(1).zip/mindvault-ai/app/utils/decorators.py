from functools import wraps
from flask import abort, redirect, url_for
from flask_login import current_user
from app.models.project import Project


def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function


def project_access_required(f):
    """Decorator to check if user has access to project"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        project_id = kwargs.get('project_id')
        if not project_id:
            abort(400, 'Project ID required')
        
        project = Project.query.get_or_404(project_id)
        
        if project.user_id != current_user.id:
            abort(403, 'Access denied to this project')
        
        return f(*args, **kwargs)
    return decorated_function


def verified_email_required(f):
    """Decorator to require verified email"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_verified:
            abort(403, 'Please verify your email address')
        return f(*args, **kwargs)
    return decorated_function
