from flask import Blueprint, request, jsonify, Response, render_template
from flask_login import login_required, current_user
from app import db
from app.models.project import Project
from app.models.chat import Chat, Message, Citation
from app.models.document import DocumentChunk
from app.services.ai_service import AIService
import time

chat_bp = Blueprint('chat', __name__)


@chat_bp.route('/<int:project_id>')
@login_required
def chat_interface(project_id):
    """Chat interface for a project (no specific chat)"""
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Get chats
    chats = project.chats.order_by(Chat.updated_at.desc()).all()
    
    return render_template('chat/interface.html',
                         project=project,
                         chats=chats,
                         chat=None)


@chat_bp.route('/<int:project_id>/<int:chat_id>')
@login_required
def view_chat(project_id, chat_id):
    """View specific chat"""
    project = Project.query.get_or_404(project_id)
    chat = Chat.query.get_or_404(chat_id)
    
    # Check access
    if project.user_id != current_user.id or chat.project_id != project_id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Get all chats for sidebar
    chats = project.chats.order_by(Chat.updated_at.desc()).all()
    
    return render_template('chat/interface.html',
                         project=project,
                         chats=chats,
                         chat=chat)


@chat_bp.route('/<int:project_id>/message', methods=['POST'])
@login_required
def send_project_message(project_id):
    """Send message in project (creates chat if needed)"""
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    user_message = data.get('message', '').strip()
    chat_id = data.get('chat_id')
    mode = data.get('mode', 'chat')  # chat, notes, quiz
    web_search = data.get('web_search', False)
    
    # Quiz-specific parameters
    quiz_answer = data.get('quiz_answer')
    quiz_question_num = data.get('quiz_question_num', 0)
    quiz_data = data.get('quiz_data')
    
    if not user_message and mode != 'quiz':
        return jsonify({'error': 'Message is required'}), 400
    
    # Get or create chat
    if chat_id:
        chat = Chat.query.get_or_404(chat_id)
        if chat.project_id != project_id:
            return jsonify({'error': 'Invalid chat'}), 400
    else:
        # Create new chat
        chat = Chat(project_id=project_id, title='New Chat')
        db.session.add(chat)
        db.session.flush()
    
    # Get all chunks from project documents with round-robin mixing
    # Strategy: Get chunks from each document separately, then interleave them
    from collections import defaultdict
    
    doc_chunks = defaultdict(list)
    for doc in project.documents.filter_by(processed=True).all():
        # Get chunks ordered by page within each document
        doc_chunks[doc.id] = doc.chunks.order_by(
            DocumentChunk.page_number,
            DocumentChunk.chunk_index
        ).all()
    
    # Interleave chunks from different documents (round-robin)
    chunks = []
    max_chunks_per_doc = max(len(c) for c in doc_chunks.values()) if doc_chunks else 0
    
    for i in range(max_chunks_per_doc):
        for doc_id in sorted(doc_chunks.keys()):
            if i < len(doc_chunks[doc_id]):
                chunks.append(doc_chunks[doc_id][i])
    
    try:
        ai_service = AIService()
        
        # Handle different modes
        if mode == 'notes':
            # Save user message
            user_msg = Message(chat_id=chat.id, role='user', content=user_message)
            db.session.add(user_msg)
            
            if not chunks:
                answer = "Please upload documents first to generate notes."
                used_chunks = []
            else:
                answer = ai_service.generate_notes(chunks)
                used_chunks = chunks[:5]
            
            # Generate title if first message
            if not chat.title or chat.title == 'New Chat':
                chat.title = user_message[:50] + ('...' if len(user_message) > 50 else '')
            
            db.session.commit()
            
            # Save assistant message
            assistant_msg = Message(
                chat_id=chat.id,
                role='assistant',
                content=answer,
                has_citations=len(used_chunks) > 0
            )
            db.session.add(assistant_msg)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'chat_id': chat.id,
                'response': answer,
                'citations': []
            })
        
        elif mode == 'quiz':
            if not chunks:
                return jsonify({
                    'success': False,
                    'error': 'Please upload documents first to generate a quiz.'
                }), 400
            
            # Handle quiz interaction
            return handle_quiz_interaction(chat, chunks, quiz_answer, quiz_question_num, quiz_data, ai_service)
        
        else:  # chat mode
            # Save user message
            user_msg = Message(chat_id=chat.id, role='user', content=user_message)
            db.session.add(user_msg)
            
            # Generate title if first message
            if not chat.title or chat.title == 'New Chat':
                chat.title = user_message[:50] + ('...' if len(user_message) > 50 else '')
            
            db.session.commit()
            
            # Check if web search is needed
            if web_search or not chunks:
                # Use hybrid mode: documents + web search
                answer, used_chunks = ai_service.chat_with_web_search(user_message, chunks)
            else:
                # Document-only mode
                if not chunks:
                    answer = "Please upload documents to this project or enable web search."
                    used_chunks = []
                else:
                    answer, used_chunks = ai_service.chat_with_context(user_message, chunks)
        
            # Save assistant message
            assistant_msg = Message(
                chat_id=chat.id,
                role='assistant',
                content=answer,
                has_citations=len(used_chunks) > 0
            )
            db.session.add(assistant_msg)
            db.session.flush()
            
            # Create citations
            citations_data = []
            for chunk in used_chunks[:5]:  # Limit to 5 citations
                citation = Citation(
                    message_id=assistant_msg.id,
                    document_id=chunk.document_id,
                    chunk_id=chunk.id,
                    page_number=chunk.page_number,
                    quoted_text=chunk.chunk_text[:200]
                )
                db.session.add(citation)
                citations_data.append({
                    'document_name': chunk.document.filename,
                    'page_number': chunk.page_number,
                    'quoted_text': chunk.chunk_text[:100]
                })
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'chat_id': chat.id,
                'response': answer,
                'citations': citations_data
            })
    
    except Exception as e:
        print(f"Error generating AI response: {e}")
        import traceback
        traceback.print_exc()
        db.session.rollback()
        
        return jsonify({
            'success': False,
            'error': str(e),
            'chat_id': chat.id if chat_id else None
        }), 500


def handle_quiz_interaction(chat, chunks, quiz_answer, quiz_question_num, quiz_data, ai_service):
    """Handle interactive quiz flow"""
    from flask import request
    data = request.get_json()
    
    # If this is the first question (no answer provided)
    if quiz_answer is None and quiz_question_num == 0:
        # Generate first question
        question_data = ai_service.generate_single_mcq(chunks, 1)
        
        if not question_data:
            return jsonify({
                'success': False,
                'error': 'Failed to generate question'
            }), 500
        
        # Update chat title
        if not chat.title or chat.title == 'New Chat':
            chat.title = 'Interactive Quiz'
        db.session.commit()
        
        return jsonify({
            'success': True,
            'chat_id': chat.id,
            'quiz_mode': True,
            'question_number': 1,
            'total_answered': 0,
            'correct_count': 0,
            'question_data': question_data,
            'max_questions': 50
        })
    
    # User submitted an answer
    if quiz_answer and quiz_data:
        is_correct, explanation, correct_answer = ai_service.check_mcq_answer(quiz_data, quiz_answer)
        
        # Save user's answer
        user_msg = Message(
            chat_id=chat.id,
            role='user',
            content=f"Answer: {quiz_answer}"
        )
        db.session.add(user_msg)
        
        # Save feedback
        feedback = f"{'✅ Correct!' if is_correct else f'❌ Incorrect. The correct answer is {correct_answer}.'}\n\n{explanation}"
        assistant_msg = Message(
            chat_id=chat.id,
            role='assistant',
            content=feedback
        )
        db.session.add(assistant_msg)
        db.session.commit()
        
        new_question_num = quiz_question_num + 1
        correct_count = data.get('correct_count', 0) + (1 if is_correct else 0)
        
        # Check if we need to ask for continuation
        if new_question_num % 10 == 1 and new_question_num > 1:
            if new_question_num > 50:
                # Reached maximum
                return jsonify({
                    'success': True,
                    'chat_id': chat.id,
                    'quiz_mode': True,
                    'quiz_complete': True,
                    'total_answered': quiz_question_num,
                    'correct_count': correct_count,
                    'feedback': feedback,
                    'is_correct': is_correct
                })
            else:
                # Ask if user wants to continue
                return jsonify({
                    'success': True,
                    'chat_id': chat.id,
                    'quiz_mode': True,
                    'ask_continue': True,
                    'total_answered': quiz_question_num,
                    'correct_count': correct_count,
                    'feedback': feedback,
                    'is_correct': is_correct
                })
        
        # Generate next question
        previous_questions = f"Questions 1-{quiz_question_num} already asked"
        question_data = ai_service.generate_single_mcq(chunks, new_question_num, previous_questions)
        
        if not question_data:
            return jsonify({
                'success': False,
                'error': 'Failed to generate next question'
            }), 500
        
        return jsonify({
            'success': True,
            'chat_id': chat.id,
            'quiz_mode': True,
            'question_number': new_question_num,
            'total_answered': quiz_question_num,
            'correct_count': correct_count,
            'question_data': question_data,
            'feedback': feedback,
            'is_correct': is_correct,
            'max_questions': 50
        })
    
    return jsonify({
        'success': False,
        'error': 'Invalid quiz request'
    }), 400


@chat_bp.route('/create', methods=['POST'])
@login_required
def create_chat():
    """Create new chat thread"""
    data = request.get_json()
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID required'}), 400
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Create chat
    chat = Chat(project_id=project_id, title='New Chat')
    db.session.add(chat)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'chat': chat.to_dict()
    })


@chat_bp.route('/<int:chat_id>/messages')
@login_required
def get_messages(chat_id):
    """Get all messages in a chat"""
    chat = Chat.query.get_or_404(chat_id)
    
    # Check access
    if chat.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    messages = chat.messages.all()
    
    return jsonify({
        'messages': [msg.to_dict() for msg in messages]
    })


@chat_bp.route('/<int:chat_id>/send', methods=['POST'])
@login_required
def send_message(chat_id):
    """Send message and get AI response"""
    chat = Chat.query.get_or_404(chat_id)
    
    # Check access
    if chat.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({'error': 'Message is required'}), 400
    
    # Save user message
    user_msg = Message(
        chat_id=chat_id,
        role='user',
        content=user_message
    )
    db.session.add(user_msg)
    
    # Generate title if first message
    if chat.messages.count() == 0:
        chat.generate_title()
    
    db.session.commit()
    
    # Get all chunks from project documents
    chunks = chat.project.get_all_chunks()
    
    if not chunks:
        # No documents uploaded
        assistant_msg = Message(
            chat_id=chat_id,
            role='assistant',
            content="Please upload documents to this project first before asking questions."
        )
        db.session.add(assistant_msg)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': assistant_msg.to_dict()
        })
    
    # Get AI response
    ai_service = AIService()
    answer, used_chunks = ai_service.chat_with_context(user_message, chunks)
    
    # Save assistant message
    assistant_msg = Message(
        chat_id=chat_id,
        role='assistant',
        content=answer,
        has_citations=len(used_chunks) > 0
    )
    db.session.add(assistant_msg)
    db.session.commit()
    
    # Create citations
    for chunk in used_chunks:
        citation = Citation(
            message_id=assistant_msg.id,
            document_id=chunk.document_id,
            chunk_id=chunk.id,
            page_number=chunk.page_number,
            quoted_text=chunk.chunk_text[:200]  # First 200 chars
        )
        db.session.add(citation)
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': assistant_msg.to_dict()
    })


@chat_bp.route('/<int:chat_id>/stream', methods=['POST'])
@login_required
def stream_message(chat_id):
    """Stream AI response"""
    chat = Chat.query.get_or_404(chat_id)
    
    # Check access
    if chat.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    user_message = data.get('message', '').strip()
    
    if not user_message:
        return jsonify({'error': 'Message is required'}), 400
    
    # Save user message
    user_msg = Message(
        chat_id=chat_id,
        role='user',
        content=user_message
    )
    db.session.add(user_msg)
    
    if chat.messages.count() == 0:
        chat.generate_title()
    
    db.session.commit()
    
    # Get chunks
    chunks = chat.project.get_all_chunks()
    
    if not chunks:
        def generate_no_docs():
            yield "Please upload documents to this project first."
        
        return Response(generate_no_docs(), mimetype='text/plain')
    
    # Stream AI response
    ai_service = AIService()
    stream = ai_service.chat_with_context(user_message, chunks, stream=True)
    
    def generate():
        full_response = ""
        for chunk in stream:
            if chunk.choices[0].delta.content:
                content = chunk.choices[0].delta.content
                full_response += content
                yield content
        
        # Save complete response
        assistant_msg = Message(
            chat_id=chat_id,
            role='assistant',
            content=full_response
        )
        db.session.add(assistant_msg)
        db.session.commit()
    
    return Response(generate(), mimetype='text/plain')


@chat_bp.route('/<int:chat_id>/delete', methods=['POST'])
@login_required
def delete_chat(chat_id):
    """Delete chat thread"""
    chat = Chat.query.get_or_404(chat_id)
    
    # Check access
    if chat.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    db.session.delete(chat)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Chat deleted successfully'
    })


@chat_bp.route('/<int:project_id>/generate-pdf', methods=['POST'])
@login_required
def generate_pdf(project_id):
    """Generate PDF from notes or content"""
    from app.services.pdf_generator import PDFGenerator
    from app.models.generated_content import GeneratedContent
    from flask import send_file
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    data = request.get_json()
    content = data.get('content', '')
    content_type = data.get('type', 'notes')  # notes, quiz, summary
    title = data.get('title', f'{content_type.capitalize()} - {project.name}')
    
    if not content:
        return jsonify({'error': 'Content is required'}), 400
    
    try:
        pdf_gen = PDFGenerator()
        
        # Generate PDF based on type
        if content_type == 'notes':
            filepath = pdf_gen.generate_notes_pdf(
                project_id=project.id,
                user_id=current_user.id,
                content=content,
                citations=[],
                title=title
            )
        elif content_type == 'quiz':
            filepath = pdf_gen.generate_quiz_pdf(
                project_id=project.id,
                user_id=current_user.id,
                quiz_content=content,
                title=title
            )
        else:  # summary
            filepath = pdf_gen.generate_summary_pdf(
                project_id=project.id,
                user_id=current_user.id,
                summary_content=content,
                citations=[],
                title=title
            )
        
        # Save to database
        generated = GeneratedContent(
            project_id=project.id,
            content_type=content_type,
            title=title,
            file_path=filepath,
            file_size=os.path.getsize(filepath)
        )
        db.session.add(generated)
        db.session.commit()
        
        # Return file for download
        return send_file(
            filepath,
            as_attachment=True,
            download_name=os.path.basename(filepath),
            mimetype='application/pdf'
        )
        
    except Exception as e:
        print(f"Error generating PDF: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': 'Failed to generate PDF'}), 500
