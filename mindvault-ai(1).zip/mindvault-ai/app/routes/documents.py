from flask import Blueprint, request, jsonify, send_file, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from app.models.project import Project
from app.models.document import Document
from app.services.document_processor import DocumentProcessor
from app.utils.validators import allowed_file, sanitize_filename
import os

documents_bp = Blueprint('documents', __name__)


@documents_bp.route('/upload/<int:project_id>', methods=['POST'])
@login_required
def upload_document(project_id):
    """Upload and process document"""
    # Verify project access
    project = Project.query.get_or_404(project_id)
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Check if files are in request
    if 'files' not in request.files:
        return jsonify({'error': 'No files uploaded'}), 400
    
    files = request.files.getlist('files')
    
    if not files or files[0].filename == '':
        return jsonify({'error': 'No files selected'}), 400
    
    uploaded_documents = []
    errors = []
    
    for file in files:
        if not allowed_file(file.filename):
            errors.append(f'{file.filename}: File type not allowed')
            continue
        
        # Sanitize filename
        filename = sanitize_filename(secure_filename(file.filename))
        
        try:
            # Process document
            processor = DocumentProcessor()
            document = processor.process_document(file, project_id, current_user.id)
            uploaded_documents.append(document.to_dict())
        
        except Exception as e:
            print(f"Error uploading {filename}: {e}")
            errors.append(f'{filename}: Failed to process')
    
    if uploaded_documents:
        return jsonify({
            'success': True,
            'message': f'{len(uploaded_documents)} document(s) uploaded successfully',
            'documents': uploaded_documents,
            'errors': errors if errors else None
        })
    else:
        return jsonify({
            'success': False,
            'error': 'No documents were uploaded',
            'errors': errors
        }), 400


@documents_bp.route('/<int:document_id>')
@login_required
def get_document(document_id):
    """Get document details"""
    document = Document.query.get_or_404(document_id)
    
    # Check access
    if document.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    return jsonify(document.to_dict())


@documents_bp.route('/<int:document_id>/download')
@login_required
def download_document(document_id):
    """Download original document"""
    document = Document.query.get_or_404(document_id)
    
    # Check access
    if document.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    if not document.original_path or not os.path.exists(document.original_path):
        return jsonify({'error': 'File not found'}), 404
    
    return send_file(
        document.original_path,
        as_attachment=True,
        download_name=document.filename
    )


@documents_bp.route('/<int:document_id>/view')
@login_required
def view_document(document_id):
    """View document in browser"""
    document = Document.query.get_or_404(document_id)
    
    # Check access
    if document.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    if not document.original_path or not os.path.exists(document.original_path):
        return jsonify({'error': 'File not found'}), 404
    
    return send_file(
        document.original_path,
        as_attachment=False,
        download_name=document.filename
    )


@documents_bp.route('/<int:document_id>', methods=['DELETE'])
@login_required
def delete_document_api(document_id):
    """Delete document (API endpoint)"""
    document = Document.query.get_or_404(document_id)
    
    # Check access
    if document.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    try:
        processor = DocumentProcessor()
        processor.delete_document(document_id)
        
        return jsonify({
            'success': True,
            'message': 'Document deleted successfully'
        })
    
    except Exception as e:
        print(f"Error deleting document: {e}")
        return jsonify({'error': 'Failed to delete document'}), 500


@documents_bp.route('/<int:document_id>/delete', methods=['POST'])
@login_required
def delete_document(document_id):
    """Delete document"""
    document = Document.query.get_or_404(document_id)
    
    # Check access
    if document.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    try:
        processor = DocumentProcessor()
        processor.delete_document(document_id)
        
        return jsonify({
            'success': True,
            'message': 'Document deleted successfully'
        })
    
    except Exception as e:
        print(f"Error deleting document: {e}")
        return jsonify({'error': 'Failed to delete document'}), 500


@documents_bp.route('/project/<int:project_id>')
@login_required
def list_documents(project_id):
    """List all documents in a project"""
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    documents = project.documents.all()
    
    return jsonify({
        'documents': [doc.to_dict() for doc in documents]
    })
