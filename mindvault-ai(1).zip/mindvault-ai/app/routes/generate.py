from flask import Blueprint, request, jsonify, send_file
from flask_login import login_required, current_user
from app import db
from app.models.project import Project
from app.models.generated_content import GeneratedContent
from app.services.ai_service import AIService
from app.services.pdf_generator import PDFGenerator
import os

generate_bp = Blueprint('generate', __name__)


@generate_bp.route('/notes', methods=['POST'])
@login_required
def generate_notes():
    """Generate study notes PDF"""
    data = request.get_json()
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID required'}), 400
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    # Get all chunks
    chunks = project.get_all_chunks()
    
    if not chunks:
        return jsonify({'error': 'No documents in project'}), 400
    
    try:
        # Generate notes content using AI
        ai_service = AIService()
        notes_content = ai_service.generate_notes(chunks)
        
        # Extract citations (simplified - using first few chunks)
        citations = []
        for chunk in chunks[:10]:
            citations.append({
                'document_name': chunk.document.filename,
                'page_number': chunk.page_number
            })
        
        # Generate PDF
        pdf_generator = PDFGenerator()
        pdf_path = pdf_generator.generate_notes_pdf(
            project_id=project.id,
            user_id=current_user.id,
            content=notes_content,
            citations=citations,
            title=f"Study Notes - {project.name}"
        )
        
        # Save to database
        generated = GeneratedContent(
            project_id=project.id,
            content_type='notes',
            title=f"Study Notes - {project.name}",
            content=notes_content,
            pdf_path=pdf_path,
            file_size=os.path.getsize(pdf_path) if os.path.exists(pdf_path) else 0
        )
        generated.set_source_documents([doc.id for doc in project.documents.all()])
        
        db.session.add(generated)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notes generated successfully',
            'content_id': generated.id,
            'download_url': f'/generate/download/{generated.id}'
        })
    
    except Exception as e:
        print(f"Error generating notes: {e}")
        return jsonify({'error': 'Failed to generate notes'}), 500


@generate_bp.route('/quiz', methods=['POST'])
@login_required
def generate_quiz():
    """Generate quiz PDF"""
    data = request.get_json()
    project_id = data.get('project_id')
    num_questions = data.get('num_questions', 10)
    
    if not project_id:
        return jsonify({'error': 'Project ID required'}), 400
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    chunks = project.get_all_chunks()
    
    if not chunks:
        return jsonify({'error': 'No documents in project'}), 400
    
    try:
        # Generate quiz using AI
        ai_service = AIService()
        quiz_content = ai_service.generate_quiz(chunks, num_questions)
        
        # Generate PDF
        pdf_generator = PDFGenerator()
        pdf_path = pdf_generator.generate_quiz_pdf(
            project_id=project.id,
            user_id=current_user.id,
            quiz_content=quiz_content,
            title=f"Quiz - {project.name}"
        )
        
        # Save to database
        generated = GeneratedContent(
            project_id=project.id,
            content_type='quiz',
            title=f"Quiz - {project.name}",
            content=quiz_content,
            pdf_path=pdf_path,
            file_size=os.path.getsize(pdf_path) if os.path.exists(pdf_path) else 0
        )
        generated.set_source_documents([doc.id for doc in project.documents.all()])
        
        db.session.add(generated)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Quiz generated successfully',
            'content_id': generated.id,
            'download_url': f'/generate/download/{generated.id}'
        })
    
    except Exception as e:
        print(f"Error generating quiz: {e}")
        return jsonify({'error': 'Failed to generate quiz'}), 500


@generate_bp.route('/summary', methods=['POST'])
@login_required
def generate_summary():
    """Generate summary PDF"""
    data = request.get_json()
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID required'}), 400
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    chunks = project.get_all_chunks()
    
    if not chunks:
        return jsonify({'error': 'No documents in project'}), 400
    
    try:
        # Generate summary using AI
        ai_service = AIService()
        summary_content = ai_service.generate_summary(chunks)
        
        # Citations
        citations = []
        for chunk in chunks[:10]:
            citations.append({
                'document_name': chunk.document.filename,
                'page_number': chunk.page_number
            })
        
        # Generate PDF
        pdf_generator = PDFGenerator()
        pdf_path = pdf_generator.generate_summary_pdf(
            project_id=project.id,
            user_id=current_user.id,
            summary_content=summary_content,
            citations=citations,
            title=f"Summary - {project.name}"
        )
        
        # Save to database
        generated = GeneratedContent(
            project_id=project.id,
            content_type='summary',
            title=f"Summary - {project.name}",
            content=summary_content,
            pdf_path=pdf_path,
            file_size=os.path.getsize(pdf_path) if os.path.exists(pdf_path) else 0
        )
        generated.set_source_documents([doc.id for doc in project.documents.all()])
        
        db.session.add(generated)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Summary generated successfully',
            'content_id': generated.id,
            'download_url': f'/generate/download/{generated.id}'
        })
    
    except Exception as e:
        print(f"Error generating summary: {e}")
        return jsonify({'error': 'Failed to generate summary'}), 500


@generate_bp.route('/download/<int:content_id>')
@login_required
def download_generated(content_id):
    """Download generated PDF"""
    content = GeneratedContent.query.get_or_404(content_id)
    
    # Check access
    if content.project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    if not content.pdf_path or not os.path.exists(content.pdf_path):
        return jsonify({'error': 'File not found'}), 404
    
    filename = f"{content.content_type}_{content.id}.pdf"
    
    return send_file(
        content.pdf_path,
        as_attachment=True,
        download_name=filename
    )


@generate_bp.route('/analyze', methods=['POST'])
@login_required
def analyze_difficulty():
    """Analyze content difficulty"""
    data = request.get_json()
    project_id = data.get('project_id')
    
    if not project_id:
        return jsonify({'error': 'Project ID required'}), 400
    
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    chunks = project.get_all_chunks()
    
    if not chunks:
        return jsonify({'error': 'No documents in project'}), 400
    
    try:
        ai_service = AIService()
        analysis = ai_service.analyze_difficulty(chunks)
        
        return jsonify({
            'success': True,
            'analysis': analysis
        })
    
    except Exception as e:
        print(f"Error analyzing difficulty: {e}")
        return jsonify({'error': 'Failed to analyze content'}), 500
