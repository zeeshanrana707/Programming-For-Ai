from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from app.models.project import Project
from app.models.generated_content import GeneratedContent
from sqlalchemy import func

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/')
@login_required
def home():
    """Main dashboard"""
    # Get user's projects
    projects = Project.query.filter_by(
        user_id=current_user.id,
        is_archived=False
    ).order_by(Project.updated_at.desc()).all()
    
    # Get recent generated content
    recent_content = GeneratedContent.query.join(Project).filter(
        Project.user_id == current_user.id
    ).order_by(GeneratedContent.created_at.desc()).limit(10).all()
    
    # Statistics
    total_projects = len(projects)
    total_documents = sum(p.documents.count() for p in projects)
    total_chats = sum(p.chats.count() for p in projects)
    total_generated = GeneratedContent.query.join(Project).filter(
        Project.user_id == current_user.id
    ).count()
    
    stats = {
        'projects': total_projects,
        'documents': total_documents,
        'chats': total_chats,
        'generated': total_generated
    }
    
    return render_template('dashboard/home.html',
                         projects=projects,
                         recent_content=recent_content,
                         stats=stats)


@dashboard_bp.route('/settings')
@login_required
def settings():
    """User settings page"""
    return render_template('dashboard/settings.html')


@dashboard_bp.route('/library')
@login_required
def library():
    """Generated content library"""
    # Get all generated content for user
    content = GeneratedContent.query.join(Project).filter(
        Project.user_id == current_user.id
    ).order_by(GeneratedContent.created_at.desc()).all()
    
    # Group by type
    notes = [c for c in content if c.content_type == 'notes']
    quizzes = [c for c in content if c.content_type == 'quiz']
    summaries = [c for c in content if c.content_type == 'summary']
    
    return render_template('dashboard/library.html',
                         notes=notes,
                         quizzes=quizzes,
                         summaries=summaries)
