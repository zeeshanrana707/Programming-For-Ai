from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from app import db
from app.models.project import Project
from app.models.chat import Chat
from app.models.generated_content import GeneratedContent

projects_bp = Blueprint('projects', __name__)


@projects_bp.route('/api/list')
@login_required
def api_list_projects():
    """API endpoint to list all user projects (for sidebar)"""
    projects = Project.query.filter_by(
        user_id=current_user.id,
        is_archived=False
    ).order_by(Project.updated_at.desc()).all()
    
    return jsonify({
        'projects': [
            {
                'id': p.id,
                'name': p.name,
                'description': p.description,
                'document_count': p.documents.count(),
                'updated_at': p.updated_at.isoformat() if p.updated_at else None
            }
            for p in projects
        ]
    })


@projects_bp.route('/')
@login_required
def list_projects():
    """List all user projects"""
    projects = Project.query.filter_by(
        user_id=current_user.id,
        is_archived=False
    ).order_by(Project.updated_at.desc()).all()
    
    return render_template('projects/list.html', projects=projects)


@projects_bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_project():
    """Create new project"""
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        description = request.form.get('description', '').strip()
        
        if not name:
            flash('Project name is required', 'error')
            return render_template('projects/create.html')
        
        project = Project(
            user_id=current_user.id,
            name=name,
            description=description
        )
        
        db.session.add(project)
        db.session.commit()
        
        flash(f'Project "{name}" created successfully!', 'success')
        return redirect(url_for('projects.view_project', project_id=project.id))
    
    return render_template('projects/create.html')


@projects_bp.route('/<int:project_id>')
@login_required
def view_project(project_id):
    """View project workspace"""
    project = Project.query.get_or_404(project_id)
    
    # Check access
    if project.user_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard.home'))
    
    # Get project data
    documents = project.documents.all()
    chats = project.chats.order_by(Chat.updated_at.desc()).all()
    generated_content = project.generated_contents.order_by(
        GeneratedContent.created_at.desc()
    ).limit(5).all()
    
    return render_template('projects/workspace.html',
                         project=project,
                         documents=documents,
                         chats=chats,
                         generated_content=generated_content)


@projects_bp.route('/<int:project_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_project(project_id):
    """Edit project"""
    project = Project.query.get_or_404(project_id)
    
    if project.user_id != current_user.id:
        flash('Access denied', 'error')
        return redirect(url_for('dashboard.home'))
    
    if request.method == 'POST':
        project.name = request.form.get('name', '').strip()
        project.description = request.form.get('description', '').strip()
        
        db.session.commit()
        flash('Project updated successfully', 'success')
        return redirect(url_for('projects.view_project', project_id=project.id))
    
    return render_template('projects/edit.html', project=project)


@projects_bp.route('/<int:project_id>/delete', methods=['POST'])
@login_required
def delete_project(project_id):
    """Delete project"""
    project = Project.query.get_or_404(project_id)
    
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    db.session.delete(project)
    db.session.commit()
    
    flash('Project deleted successfully', 'success')
    return redirect(url_for('dashboard.home'))


@projects_bp.route('/<int:project_id>/archive', methods=['POST'])
@login_required
def archive_project(project_id):
    """Archive project"""
    project = Project.query.get_or_404(project_id)
    
    if project.user_id != current_user.id:
        return jsonify({'error': 'Access denied'}), 403
    
    project.is_archived = True
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Project archived'})
