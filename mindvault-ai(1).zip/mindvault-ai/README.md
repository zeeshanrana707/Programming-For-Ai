# MindVault AI

🧠 Intelligent Document Research Assistant - Chat with your documents using AI

## ⚡ Quick Start (3 Steps)

```bash
# 1. Install dependencies
python install_dependencies.py

# 2. Edit .env file and add your GROQ_API_KEY

# 3. Run the application
python app.py
```

### Access the Application:

Open your browser: **http://localhost:5000**

**Default Login:**
- Email: `test@mindvault.ai`
- Password: `Test123!`

---

## 🎯 Features

- 📄 **Upload Documents** - PDF, DOCX, TXT files
- 💬 **Chat with AI** - Ask questions about your documents
- 🌐 **Web Search Mode** - Answer any question, not just documents
- 📝 **Generate Notes** - Automatic study notes from documents
- 🎓 **Interactive Quiz** - Generate MCQ questions from content
- 📊 **PDF Export** - Download notes as PDF
- 🔍 **Source Citations** - See which page information came from
- 🌍 **Multi-language** - English and Urdu support

---

## 📋 Requirements

- Python 3.8 or higher
- SQL Server LocalDB (or SQL Server Express)
- Groq API Key (free from https://console.groq.com)

---

## 🔧 Configuration

Edit the `.env` file:

```env
# AI API Key (REQUIRED)
GROQ_API_KEY=your-api-key-here

# Database (already configured)
DB_SERVER=(localdb)\MSSQLLocalDB
DB_NAME=mindvault_db

# Security
SECRET_KEY=your-secret-key-here
```

**Get your free Groq API key:** https://console.groq.com

---

## 📁 Project Structure

```
mindvault-ai/
├── app/                     # Application code
│   ├── models/             # Database models
│   ├── routes/             # URL endpoints
│   ├── services/           # Business logic (AI, documents)
│   ├── templates/          # HTML templates
│   └── static/             # CSS, JS, uploads
├── venv/                   # Virtual environment
├── .env                    # Configuration
├── app.py                  # Main entry point
└── install_dependencies.py # Setup script
```

---

## 🚀 Usage

### 1. Create a Project
- Click "New Project"
- Give it a name and description

### 2. Upload Documents
- Click "Upload Documents"
- Select PDF, DOCX, or TXT files
- Wait for processing to complete

### 3. Chat with Documents
- Click "Chat" on your project
- Ask questions about your documents
- Toggle "Web Search" for general questions

### 4. Generate Notes
- Select "Notes" mode
- Type: "Generate comprehensive study notes"
- Download as PDF

### 5. Take a Quiz
- Select "Quiz" mode
- Answer interactive MCQ questions
- Get instant feedback

---

## ❌ Troubleshooting

### Error: "No module named 'flask_sqlalchemy'"

**Solution:** Install dependencies first:
```bash
python install_dependencies.py
```

Then run:
```bash
python app.py
```

### Error: "GROQ_API_KEY not found"

**Solution:** 
1. Get API key from https://console.groq.com
2. Edit `.env` file
3. Add: `GROQ_API_KEY=your-actual-key-here`

### Error: "Database connection failed"

**Solution:** 
1. Check if SQL Server LocalDB is installed: `sqllocaldb info`
2. If not, download SQL Server Express
3. Or run: `create_database.sql`

### Chat not responding

**Solution:**
- Check terminal for errors
- Verify internet connection (needs Groq API)
- Check if GROQ_API_KEY is correct

---

## 📚 Documentation

- **QUICK_START.md** - Step-by-step setup guide
- **COMPLETE_DOCUMENTATION.md** - Full technical documentation
- **PROJECT_STRUCTURE.md** - Project organization
- **CLEANUP_SUMMARY.md** - Recent changes explained

---

## 🛠️ Tech Stack

- **Backend:** Flask (Python web framework)
- **Database:** Microsoft SQL Server
- **AI:** Groq API (LLaMA 3.1 models)
- **Document Processing:** PyPDF, pdfplumber, python-docx
- **PDF Generation:** ReportLab
- **Frontend:** HTML, CSS, JavaScript (Vanilla)

---

## 🎨 Key Features Explained

### Round-Robin Document Processing
When you have multiple documents, the AI reads chunks from all documents evenly, ensuring comprehensive answers.

### Streaming Text Animation
AI responses appear word-by-word like ChatGPT for a better user experience.

### Interactive Quiz System
- Generates one question at a time
- Instant feedback with explanations
- Progress tracking
- Back/Exit functionality

### Smart Context Building
The AI selects the most relevant chunks from your documents to provide accurate answers.

---

## 📊 Database Schema

- **Users** - User accounts
- **Projects** - Document collections
- **Documents** - Uploaded files
- **DocumentChunks** - Searchable text segments
- **Chats** - Conversation threads
- **Messages** - Chat messages with citations
- **GeneratedContent** - Notes and PDFs

---

## 🔒 Security Features

- ✅ Password hashing (bcrypt)
- ✅ Session management (Flask-Login)
- ✅ Rate limiting (Flask-Limiter)
- ✅ SQL injection prevention (SQLAlchemy ORM)
- ✅ CSRF protection (Flask-WTF)

---

## 🤝 Contributing

This is a complete, production-ready application. Feel free to:
- Add new features
- Improve the UI
- Add more document formats
- Enhance AI prompts

---

## 📝 License

This project is for educational and research purposes.

---

## 🆘 Support

For detailed technical information, see:
- **COMPLETE_DOCUMENTATION.md** - Full technical guide
- **QUICK_START.md** - Setup instructions

---

**Ready to start?** Run `python install_dependencies.py` then `python app.py` 🚀
