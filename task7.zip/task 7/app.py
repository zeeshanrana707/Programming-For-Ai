from flask import Flask, render_template, request, jsonify
from weather_service import WeatherService

app = Flask(__name__)

# Route to serve the main dashboard page
@app.route('/')
def index():
    return render_template('index.html')

# API Route to handle weather requests
@app.route('/api/weather', methods=['POST'])
def get_weather():
    # Extract data from the JSON request sent by your Vanilla JS frontend
    data = request.get_json()
    city = data.get('city')
    api_key = data.get('api_key')

    if not city or not api_key:
        return jsonify({"success": False, "error": "City and API Key are required."}), 400

    # Initialize the service with the user's API key
    service = WeatherService(api_key)
    success, raw_data, error = service.get_weather(city)

    if success:
        # Format the raw OpenWeatherMap data into our clean structure 
        formatted_data = WeatherService.format_weather_data(raw_data)
        return jsonify({"success": True, "data": formatted_data})
    else:
        return jsonify({"success": False, "error": error}), 400

# API Route for Dynamic Theming 
@app.route('/api/theme/<condition>', methods=['GET'])
def get_theme(condition):
    themes = {
        'clear': {'primary': '#87CEEB', 'secondary': '#E0F6FF', 'text': '#333'},
        'clouds': {'primary': '#BDC3C7', 'secondary': '#ECF0F1', 'text': '#2C3E50'},
        'rain': {'primary': '#3498DB', 'secondary': '#D6EAF8', 'text': '#1A5276'},
        'snow': {'primary': '#FFFFFF', 'secondary': '#F0F8FF', 'text': '#7F8C8D'},
        'thunderstorm': {'primary': '#9B59B6', 'secondary': '#EBDEF0', 'text': '#4A235A'},
        'mist': {'primary': '#95A5A6', 'secondary': '#F2F4F4', 'text': '#2E4053'}
    }
    return jsonify(themes.get(condition, {'primary': '#34495E', 'secondary': '#AEB6BF', 'text': '#FFFFFF'}))

if __name__ == '__main__':
    # Flask runs on port 5000 by default 
    app.run(debug=True, host='127.0.0.1', port=5000)
    