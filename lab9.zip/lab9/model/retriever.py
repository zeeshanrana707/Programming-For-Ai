import json
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from utils.preprocessing import preprocess

# Load data
with open("data/data.json") as f:
    data = json.load(f)

# Load embedding model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Prepare questions
questions = [preprocess(d["question"]) for d in data]

# Convert to embeddings
embeddings = model.encode(questions)

# Convert to numpy float32 (IMPORTANT for FAISS)
embeddings = np.array(embeddings).astype('float32')

# Create FAISS index
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)

def get_answer(query):
    if "all guns name" in query.lower():
        weapons = list(set([d["weapon"] for d in data if d["weapon"] != "none"]))
        return "Available guns: " + ", ".join(weapons)
    if "all guns" in query.lower():
        weapons = list(set([d["weapon"] for d in data if d["weapon"] != "none"]))
        return ", ".join(weapons)
    query_clean = preprocess(query)

    filters = extract_filters(query)
    category = detect_category(query)

    filtered_data = data

    # 🔹 Apply category filter
    if category:
        filtered_data = [d for d in filtered_data if d.get("category") == category]

    # 🔹 Apply weapon filter
    if filters["weapon"]:
        filtered_data = [
            d for d in filtered_data 
            if d.get("weapon","").upper() in filters["weapon"]
        ]

    # 🔹 Apply playstyle filter
    if filters["playstyle"]:
        filtered_data = [d for d in filtered_data if d.get("playstyle") == filters["playstyle"]]

    # 🔹 Apply mode filter
    if filters["mode"]:
        filtered_data = [d for d in filtered_data if d.get("mode") == filters["mode"] or d.get("mode") == "all"]

    # 🔥 Fallback if empty
    if not filtered_data:
        filtered_data = data

    if category == "comparison" and filters["weapon"]:
        weapons = filters["weapon"]

        responses = []

        for w in weapons:
            for d in data:
                if d.get("weapon","").upper() == w and d.get("category") == "comparison":
                    responses.append(d["answer"])

        if responses:
            return " | ".join(responses)

    # 🔥 IMPORTANT: build embeddings for filtered data
    questions = [preprocess(d["question"]) for d in filtered_data]

    emb = model.encode(questions)
    emb = np.array(emb).astype('float32')

    temp_index = faiss.IndexFlatL2(emb.shape[1])
    temp_index.add(emb)

    query_vec = model.encode([query_clean])
    query_vec = np.array(query_vec).astype('float32')

    distances, indices = temp_index.search(query_vec, k=1)

    return filtered_data[indices[0][0]]["answer"]

def extract_filters(query):
    query = query.lower()

    weapons = ["ak47", "m4", "qq9", "fennec", "dl q33", "locus"]

    detected = {
        "weapon": [],   # 🔥 CHANGE: list instead of single
        "playstyle": None,
        "mode": None
    }

    for w in weapons:
        if w in query:
            detected["weapon"].append(w.upper())

    return detected

def detect_category(query):
    query = query.lower()

    # 🔥 improved detection
    if "loadout" in query or "attachments" in query:
        return "loadout"

    if (
        "vs" in query or
        "which is best" in query or
        "which gun is best" in query or   # ✅ ADD THIS
        "best gun" in query or            # ✅ ADD THIS
        "better" in query
    ):
        return "comparison"

    if "how" in query:
        return "strategy"

    if "tips" in query:
        return "tips"

    return None


def detect_category(query):
    query = query.lower()

    comparison_keywords = ["vs", "better", "best gun", "which gun", "compare"]

    if any(word in query for word in ["loadout", "attachments"]):
        return "loadout"

    if any(word in query for word in comparison_keywords):
        return "comparison"

    if "how" in query:
        return "strategy"

    if "tips" in query:
        return "tips"

    return None