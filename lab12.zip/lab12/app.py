"""
Library QnA Bot - Flask Application
Uses Hugging Face MiniLM + FAISS for semantic search
"""

from flask import Flask, render_template, request, jsonify
import json
import os
import numpy as np

# Import our custom modules
from models.preprocessor import TextPreprocessor
from models.embeddings import EmbeddingGenerator
from models.faiss_search import FAISSSearchEngine


# Initialize Flask app
app = Flask(__name__)

# Configuration
DATA_DIR = 'data'
QA_DATASET_PATH = 'library_qa_dataset.json'
INDEX_PATH = os.path.join(DATA_DIR, 'faiss_library.index')
EMBEDDINGS_PATH = os.path.join(DATA_DIR, 'question_embeddings.pkl')

# Global variables (loaded on startup)
preprocessor = None
embedding_generator = None
search_engine = None
qa_pairs = []


def load_dataset():
    """Load QA dataset from JSON file"""
    print("\n" + "="*50)
    print("Loading QA Dataset...")
    print("="*50)
    
    with open(QA_DATASET_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    qa_pairs = data['qa_pairs']
    print(f"✓ Loaded {len(qa_pairs)} QA pairs")
    
    return qa_pairs


def initialize_system():
    """Initialize the QnA system (preprocessing, embeddings, FAISS)"""
    global preprocessor, embedding_generator, search_engine, qa_pairs
    
    print("\n" + "="*50)
    print("INITIALIZING LIBRARY QnA BOT")
    print("="*50)
    
    # Step 1: Load dataset
    qa_pairs = load_dataset()
    
    # Step 2: Initialize preprocessor
    print("\n[1/4] Initializing Text Preprocessor...")
    preprocessor = TextPreprocessor()
    
    # Preprocess all questions
    processed_pairs = preprocessor.preprocess_dataset(qa_pairs)
    print(f"✓ Preprocessed {len(processed_pairs)} questions")
    
    # Step 3: Initialize embedding generator
    print("\n[2/4] Loading Embedding Model (MiniLM)...")
    embedding_generator = EmbeddingGenerator()
    
    # Step 4: Generate or load embeddings
    print("\n[3/4] Generating Question Embeddings...")
    
    # Check if embeddings already exist
    if os.path.exists(EMBEDDINGS_PATH):
        print("  Found cached embeddings, loading...")
        question_embeddings = embedding_generator.load_embeddings(EMBEDDINGS_PATH)
    else:
        print("  Generating new embeddings...")
        # Extract preprocessed questions
        questions = [pair['question'] for pair in processed_pairs]
        
        # Generate embeddings
        question_embeddings = embedding_generator.encode_questions(questions)
        
        # Save for future use
        embedding_generator.save_embeddings(question_embeddings, EMBEDDINGS_PATH)
    
    # Step 5: Initialize FAISS search engine
    print("\n[4/4] Building FAISS Index...")
    search_engine = FAISSSearchEngine(embedding_dim=384)
    
    # Check if index already exists
    if os.path.exists(INDEX_PATH):
        print("  Found existing index, loading...")
        search_engine.load_index(INDEX_PATH)
    else:
        print("  Creating new index...")
        search_engine.create_index('flat')
        search_engine.add_vectors(question_embeddings, processed_pairs)
        
        # Save index
        search_engine.save_index(INDEX_PATH)
    
    # Print statistics
    stats = search_engine.get_stats()
    print("\n" + "="*50)
    print("SYSTEM READY!")
    print("="*50)
    print(f"  Total QA pairs: {len(qa_pairs)}")
    print(f"  Vectors in index: {stats['total_vectors']}")
    print(f"  Embedding dimension: {stats['embedding_dim']}")
    print(f"  Model: sentence-transformers/all-MiniLM-L6-v2")
    print("="*50 + "\n")


def search_answer(user_question, k=3, threshold=0.3):
    """
    Search for answer to user's question
    
    Args:
        user_question (str): User's question
        k (int): Number of results to return
        threshold (float): Minimum similarity threshold
        
    Returns:
        dict: Response with answer and metadata
    """
    # Preprocess question
    processed_question = preprocessor.preprocess_question(user_question)
    
    # Generate embedding
    query_embedding = embedding_generator.encode_text(processed_question)
    
    # Search in FAISS
    results = search_engine.search_with_threshold(
        query_embedding, 
        threshold=threshold, 
        k=k
    )
    
    if not results:
        return {
            'found': False,
            'message': "I'm not sure about that. Could you rephrase your question?",
            'confidence': 0.0
        }
    
    # Get best match
    best_match = results[0]
    
    # Prepare response
    response = {
        'found': True,
        'answer': best_match['answer'],
        'confidence': best_match['similarity'],
        'matched_question': best_match['qa_pair'].get('original_question', best_match['question']),
        'category': best_match['category'],
        'alternative_questions': []
    }
    
    # Add alternative questions if available
    if len(results) > 1:
        for result in results[1:]:
            response['alternative_questions'].append({
                'question': result['qa_pair'].get('original_question', result['question']),
                'confidence': result['similarity']
            })
    
    return response


# ============================================
# FLASK ROUTES
# ============================================

@app.route('/')
def index():
    """Render main page"""
    return render_template('index.html')


@app.route('/ask', methods=['POST'])
def ask():
    """
    Handle user questions
    
    Request JSON:
        {
            "question": "How do I borrow a book?"
        }
    
    Response JSON:
        {
            "found": true,
            "answer": "To borrow a book...",
            "confidence": 0.95,
            "matched_question": "How do I borrow a book from the library?",
            "category": "borrowing"
        }
    """
    try:
        data = request.get_json()
        user_question = data.get('question', '').strip()
        
        if not user_question:
            return jsonify({
                'found': False,
                'message': 'Please enter a question.'
            })
        
        # Search for answer
        response = search_answer(user_question, k=3, threshold=0.3)
        
        return jsonify(response)
    
    except Exception as e:
        print(f"Error in /ask: {str(e)}")
        return jsonify({
            'found': False,
            'message': 'An error occurred. Please try again.',
            'error': str(e)
        }), 500


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """
    Get system statistics
    
    Response JSON:
        {
            "total_qa_pairs": 60,
            "total_vectors": 60,
            "embedding_dim": 384,
            "model_name": "all-MiniLM-L6-v2"
        }
    """
    try:
        faiss_stats = search_engine.get_stats()
        model_info = embedding_generator.get_model_info()
        
        stats = {
            'total_qa_pairs': len(qa_pairs),
            'total_vectors': faiss_stats['total_vectors'],
            'embedding_dim': faiss_stats['embedding_dim'],
            'model_name': model_info['model_name'],
            'index_type': faiss_stats.get('index_type', 'Unknown')
        }
        
        return jsonify(stats)
    
    except Exception as e:
        print(f"Error in /api/stats: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/categories', methods=['GET'])
def get_categories():
    """
    Get all question categories
    
    Response JSON:
        {
            "categories": ["borrowing", "searching", "membership", ...]
        }
    """
    try:
        categories = list(set(pair.get('category', 'general') for pair in qa_pairs))
        categories.sort()
        
        return jsonify({'categories': categories})
    
    except Exception as e:
        print(f"Error in /api/categories: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/questions', methods=['GET'])
def get_all_questions():
    """
    Get all questions (for browsing)
    
    Response JSON:
        {
            "questions": [
                {
                    "id": 1,
                    "question": "How do I borrow a book?",
                    "category": "borrowing"
                },
                ...
            ]
        }
    """
    try:
        questions = [
            {
                'id': pair['id'],
                'question': pair['question'],
                'category': pair.get('category', 'general')
            }
            for pair in qa_pairs
        ]
        
        return jsonify({'questions': questions})
    
    except Exception as e:
        print(f"Error in /api/questions: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'system_initialized': search_engine is not None
    })


# ============================================
# MAIN
# ============================================

if __name__ == '__main__':
    # Create data directory if it doesn't exist
    os.makedirs(DATA_DIR, exist_ok=True)
    
    # Initialize the system
    initialize_system()
    
    # Run Flask app
    print("\n🚀 Starting Flask server...")
    print("📍 Open your browser and go to: http://127.0.0.1:5000")
    print("\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
