/**
 * Library QnA Bot - Frontend JavaScript
 * Handles user interactions and API communication
 */

// DOM Elements
const questionForm = document.getElementById('question-form');
const questionInput = document.getElementById('question-input');
const sendBtn = document.getElementById('send-btn');
const messagesContainer = document.getElementById('messages');
const exampleBtns = document.querySelectorAll('.example-btn');

// State
let isProcessing = false;

/**
 * Initialize the application
 */
function init() {
    console.log('🚀 Library QnA Bot initialized');
    
    // Load system stats
    loadSystemStats();
    
    // Setup event listeners
    setupEventListeners();
    
    // Focus input
    questionInput.focus();
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Form submission
    questionForm.addEventListener('submit', handleSubmit);
    
    // Example question buttons
    exampleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const question = btn.getAttribute('data-question');
            questionInput.value = question;
            questionInput.focus();
        });
    });
    
    // Enter key to submit
    questionInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            questionForm.dispatchEvent(new Event('submit'));
        }
    });
}

/**
 * Handle form submission
 */
async function handleSubmit(e) {
    e.preventDefault();
    
    if (isProcessing) return;
    
    const question = questionInput.value.trim();
    
    if (!question) {
        return;
    }
    
    // Disable input
    isProcessing = true;
    sendBtn.disabled = true;
    questionInput.disabled = true;
    
    // Add user message
    addUserMessage(question);
    
    // Clear input
    questionInput.value = '';
    
    // Show typing indicator
    showTypingIndicator();
    
    try {
        // Send request to backend
        const response = await fetch('/ask', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question: question })
        });
        
        const data = await response.json();
        
        // Remove typing indicator
        hideTypingIndicator();
        
        // Add bot response
        if (data.found) {
            addBotMessage(data);
        } else {
            addBotMessage({
                answer: data.message || "I'm not sure about that. Could you rephrase your question?",
                confidence: 0,
                found: false
            });
        }
        
    } catch (error) {
        console.error('Error:', error);
        hideTypingIndicator();
        addBotMessage({
            answer: "Sorry, something went wrong. Please try again.",
            confidence: 0,
            found: false
        });
    } finally {
        // Re-enable input
        isProcessing = false;
        sendBtn.disabled = false;
        questionInput.disabled = false;
        questionInput.focus();
    }
}

/**
 * Add user message to chat
 */
function addUserMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user-message';
    
    messageDiv.innerHTML = `
        <div class="message-avatar">👤</div>
        <div class="message-content">
            <div class="message-text">${escapeHtml(text)}</div>
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    scrollToBottom();
}

/**
 * Add bot message to chat
 */
function addBotMessage(data) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    
    let confidenceBadge = '';
    let confidenceClass = '';
    
    if (data.found && data.confidence) {
        const confidencePercent = (data.confidence * 100).toFixed(0);
        
        if (data.confidence >= 0.7) {
            confidenceClass = 'confidence-high';
        } else if (data.confidence >= 0.5) {
            confidenceClass = 'confidence-medium';
        } else {
            confidenceClass = 'confidence-low';
        }
        
        confidenceBadge = `
            <span class="confidence-badge ${confidenceClass}">
                Confidence: ${confidencePercent}%
            </span>
        `;
    }
    
    let matchedQuestionHtml = '';
    if (data.matched_question) {
        matchedQuestionHtml = `
            <div class="matched-question">
                <strong>📌 Matched Question:</strong><br>
                "${escapeHtml(data.matched_question)}"
            </div>
        `;
    }
    
    let alternativesHtml = '';
    if (data.alternative_questions && data.alternative_questions.length > 0) {
        const altList = data.alternative_questions
            .map(alt => {
                const conf = (alt.confidence * 100).toFixed(0);
                return `<li>• ${escapeHtml(alt.question)} (${conf}%)</li>`;
            })
            .join('');
        
        alternativesHtml = `
            <div class="alternatives">
                <strong>💡 Similar Questions:</strong>
                <ul>${altList}</ul>
            </div>
        `;
    }
    
    messageDiv.innerHTML = `
        <div class="message-avatar">🤖</div>
        <div class="message-content">
            <div class="message-text">
                ${escapeHtml(data.answer)}
                ${confidenceBadge}
            </div>
            ${matchedQuestionHtml}
            ${alternativesHtml}
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    scrollToBottom();
}

/**
 * Show typing indicator
 */
function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator';
    typingDiv.id = 'typing-indicator';
    
    typingDiv.innerHTML = `
        <div class="message-avatar">🤖</div>
        <div class="message-content">
            <div class="message-text">
                <div class="typing-indicator">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            </div>
        </div>
    `;
    
    messagesContainer.appendChild(typingDiv);
    scrollToBottom();
}

/**
 * Hide typing indicator
 */
function hideTypingIndicator() {
    const typingIndicator = document.getElementById('typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

/**
 * Scroll messages to bottom
 */
function scrollToBottom() {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

/**
 * Load system statistics
 */
async function loadSystemStats() {
    try {
        const response = await fetch('/api/stats');
        const data = await response.json();
        
        // Update stats display
        document.getElementById('stat-qa-pairs').textContent = data.total_qa_pairs || '-';
        
        console.log('📊 System Stats:', data);
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Format confidence as percentage
 */
function formatConfidence(confidence) {
    return `${(confidence * 100).toFixed(0)}%`;
}

/**
 * Get confidence level text
 */
function getConfidenceLevel(confidence) {
    if (confidence >= 0.7) return 'High';
    if (confidence >= 0.5) return 'Medium';
    return 'Low';
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// Log version info
console.log('%c Library QnA Bot ', 'background: #2563eb; color: white; padding: 5px 10px; border-radius: 3px;');
console.log('Powered by: Hugging Face MiniLM + FAISS');
console.log('Version: 1.0.0');
