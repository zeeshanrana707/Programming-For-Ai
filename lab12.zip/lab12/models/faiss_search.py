"""
FAISS Vector Search Module
Stores embeddings and performs similarity search
"""

import faiss
import numpy as np
import pickle
import os


class FAISSSearchEngine:
    """
    Manages FAISS index for fast similarity search
    """
    
    def __init__(self, embedding_dim=384):
        """
        Initialize FAISS search engine
        
        Args:
            embedding_dim (int): Dimension of embeddings (384 for MiniLM)
        """
        self.embedding_dim = embedding_dim
        self.index = None
        self.qa_pairs = []  # Store QA pairs corresponding to vectors
        self.is_trained = False
        
        print(f"FAISS Search Engine initialized (dim={embedding_dim})")
    
    def create_index(self, index_type='flat'):
        """
        Create a FAISS index
        
        Args:
            index_type (str): Type of index ('flat' or 'ivf')
                - 'flat': Exact search, slower but accurate
                - 'ivf': Approximate search, faster for large datasets
        """
        if index_type == 'flat':
            # IndexFlatL2: Exact search using L2 (Euclidean) distance
            # Best for small to medium datasets (< 1M vectors)
            self.index = faiss.IndexFlatL2(self.embedding_dim)
            print("✓ Created Flat index (exact search)")
            
        elif index_type == 'ivf':
            # IndexIVFFlat: Approximate search, faster for large datasets
            # Requires training
            quantizer = faiss.IndexFlatL2(self.embedding_dim)
            n_clusters = 10  # Number of clusters
            self.index = faiss.IndexIVFFlat(quantizer, self.embedding_dim, n_clusters)
            print(f"✓ Created IVF index (approximate search, {n_clusters} clusters)")
            
        else:
            raise ValueError(f"Unknown index type: {index_type}")
    
    def add_vectors(self, embeddings, qa_pairs):
        """
        Add embeddings to the index
        
        Args:
            embeddings (np.ndarray): Question embeddings (n_questions x 384)
            qa_pairs (list): Corresponding QA pair dictionaries
        """
        if self.index is None:
            self.create_index('flat')
        
        # Ensure embeddings are float32 (FAISS requirement)
        embeddings = embeddings.astype('float32')
        
        # For IVF index, need to train first
        if isinstance(self.index, faiss.IndexIVFFlat) and not self.is_trained:
            print("Training IVF index...")
            self.index.train(embeddings)
            self.is_trained = True
            print("✓ Index trained")
        
        # Add vectors to index
        self.index.add(embeddings)
        
        # Store QA pairs
        self.qa_pairs = qa_pairs
        
        print(f"✓ Added {len(embeddings)} vectors to index")
        print(f"  Total vectors in index: {self.index.ntotal}")
    
    def search(self, query_embedding, k=3):
        """
        Search for similar questions
        
        Args:
            query_embedding (np.ndarray): Query vector (384 dimensions)
            k (int): Number of results to return
            
        Returns:
            list: List of dictionaries with results
        """
        if self.index is None or self.index.ntotal == 0:
            raise ValueError("Index is empty. Add vectors first.")
        
        # Ensure query is 2D array and float32
        if query_embedding.ndim == 1:
            query_embedding = query_embedding.reshape(1, -1)
        query_embedding = query_embedding.astype('float32')
        
        # Search
        # distances: L2 distances (lower is better)
        # indices: Indices of nearest neighbors
        distances, indices = self.index.search(query_embedding, k)
        
        # Convert to results
        results = []
        for i, (dist, idx) in enumerate(zip(distances[0], indices[0])):
            if idx == -1:  # FAISS returns -1 if not enough results
                continue
            
            # Convert L2 distance to similarity score (0-1, higher is better)
            # L2 distance: 0 = identical, larger = more different
            # We convert to similarity: 1 / (1 + distance)
            similarity = 1 / (1 + dist)
            
            result = {
                'rank': i + 1,
                'qa_pair': self.qa_pairs[idx],
                'distance': float(dist),
                'similarity': float(similarity),
                'question': self.qa_pairs[idx]['question'],
                'answer': self.qa_pairs[idx]['answer'],
                'category': self.qa_pairs[idx].get('category', 'general')
            }
            results.append(result)
        
        return results
    
    def search_with_threshold(self, query_embedding, threshold=0.5, k=3):
        """
        Search and filter by similarity threshold
        
        Args:
            query_embedding (np.ndarray): Query vector
            threshold (float): Minimum similarity score (0-1)
            k (int): Maximum number of results
            
        Returns:
            list: Filtered results above threshold
        """
        results = self.search(query_embedding, k=k)
        
        # Filter by threshold
        filtered = [r for r in results if r['similarity'] >= threshold]
        
        return filtered
    
    def save_index(self, filepath):
        """
        Save FAISS index to disk
        
        Args:
            filepath (str): Path to save index
        """
        if self.index is None:
            raise ValueError("No index to save")
        
        # Create directory if needed
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save index
        faiss.write_index(self.index, filepath)
        
        # Save QA pairs separately
        qa_filepath = filepath.replace('.index', '_qa.pkl')
        with open(qa_filepath, 'wb') as f:
            pickle.dump(self.qa_pairs, f)
        
        print(f"✓ Index saved to {filepath}")
        print(f"✓ QA pairs saved to {qa_filepath}")
    
    def load_index(self, filepath):
        """
        Load FAISS index from disk
        
        Args:
            filepath (str): Path to index file
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Index file not found: {filepath}")
        
        # Load index
        self.index = faiss.read_index(filepath)
        
        # Load QA pairs
        qa_filepath = filepath.replace('.index', '_qa.pkl')
        if os.path.exists(qa_filepath):
            with open(qa_filepath, 'rb') as f:
                self.qa_pairs = pickle.load(f)
        
        print(f"✓ Index loaded from {filepath}")
        print(f"  Total vectors: {self.index.ntotal}")
    
    def get_stats(self):
        """
        Get index statistics
        
        Returns:
            dict: Index statistics
        """
        if self.index is None:
            return {
                'total_vectors': 0,
                'embedding_dim': self.embedding_dim,
                'is_trained': False
            }
        
        return {
            'total_vectors': self.index.ntotal,
            'embedding_dim': self.embedding_dim,
            'is_trained': self.is_trained,
            'index_type': type(self.index).__name__
        }


# Utility function
def create_and_populate_index(embeddings, qa_pairs, embedding_dim=384):
    """
    Quick function to create and populate an index
    
    Args:
        embeddings (np.ndarray): Question embeddings
        qa_pairs (list): QA pair dictionaries
        embedding_dim (int): Embedding dimension
        
    Returns:
        FAISSSearchEngine: Populated search engine
    """
    engine = FAISSSearchEngine(embedding_dim)
    engine.create_index('flat')
    engine.add_vectors(embeddings, qa_pairs)
    return engine


if __name__ == "__main__":
    # Test FAISS search engine
    print("Testing FAISS Search Engine\n")
    print("=" * 50)
    
    # Create dummy data
    embedding_dim = 384
    n_questions = 5
    
    # Random embeddings for testing
    np.random.seed(42)
    embeddings = np.random.randn(n_questions, embedding_dim).astype('float32')
    
    # Dummy QA pairs
    qa_pairs = [
        {'id': i, 'question': f'Question {i}', 'answer': f'Answer {i}', 'category': 'test'}
        for i in range(n_questions)
    ]
    
    # Create and populate index
    engine = FAISSSearchEngine(embedding_dim)
    engine.create_index('flat')
    engine.add_vectors(embeddings, qa_pairs)
    
    print(f"\nIndex stats: {engine.get_stats()}")
    
    # Test search
    query = embeddings[0]  # Use first embedding as query
    results = engine.search(query, k=3)
    
    print(f"\n\nSearch results for query (should match Question 0):")
    for result in results:
        print(f"  Rank {result['rank']}: {result['question']}")
        print(f"    Similarity: {result['similarity']:.4f}")
        print(f"    Distance: {result['distance']:.4f}")
