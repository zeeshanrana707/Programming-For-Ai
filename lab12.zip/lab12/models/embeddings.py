"""
Embedding Generation Module
Uses Hugging Face sentence-transformers to convert text to vectors
"""

from sentence_transformers import SentenceTransformer
import numpy as np
import pickle
import os


class EmbeddingGenerator:
    """
    Generates embeddings using Hugging Face MiniLM model
    """
    
    def __init__(self, model_name='sentence-transformers/all-MiniLM-L6-v2'):
        """
        Initialize the embedding model
        
        Args:
            model_name (str): Hugging Face model identifier
        """
        print(f"Loading embedding model: {model_name}")
        
        # Load the pre-trained model
        # This model converts text to 384-dimensional vectors
        self.model = SentenceTransformer(model_name)
        
        # Model info
        self.model_name = model_name
        self.embedding_dim = 384  # MiniLM produces 384-dimensional vectors
        
        print(f"✓ Model loaded successfully!")
        print(f"  - Embedding dimension: {self.embedding_dim}")
    
    def encode_text(self, text):
        """
        Convert a single text to embedding vector
        
        Args:
            text (str): Input text
            
        Returns:
            np.ndarray: Embedding vector (384 dimensions)
        """
        if not text:
            # Return zero vector for empty text
            return np.zeros(self.embedding_dim)
        
        # Generate embedding
        embedding = self.model.encode(text, convert_to_numpy=True)
        
        return embedding
    
    def encode_batch(self, texts, batch_size=32, show_progress=True):
        """
        Convert multiple texts to embeddings (more efficient)
        
        Args:
            texts (list): List of text strings
            batch_size (int): Number of texts to process at once
            show_progress (bool): Show progress bar
            
        Returns:
            np.ndarray: Array of embeddings (n_texts x 384)
        """
        if not texts:
            return np.array([])
        
        print(f"Encoding {len(texts)} texts...")
        
        # Batch encoding is faster than one-by-one
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress,
            convert_to_numpy=True
        )
        
        print(f"✓ Encoded {len(texts)} texts")
        
        return embeddings
    
    def encode_questions(self, questions):
        """
        Encode a list of questions
        
        Args:
            questions (list): List of question strings
            
        Returns:
            np.ndarray: Question embeddings
        """
        return self.encode_batch(questions)
    
    def encode_answers(self, answers):
        """
        Encode a list of answers
        
        Args:
            answers (list): List of answer strings
            
        Returns:
            np.ndarray: Answer embeddings
        """
        return self.encode_batch(answers)
    
    def save_embeddings(self, embeddings, filepath):
        """
        Save embeddings to disk
        
        Args:
            embeddings (np.ndarray): Embeddings to save
            filepath (str): Path to save file
        """
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # Save as pickle file
        with open(filepath, 'wb') as f:
            pickle.dump(embeddings, f)
        
        print(f"✓ Embeddings saved to {filepath}")
    
    def load_embeddings(self, filepath):
        """
        Load embeddings from disk
        
        Args:
            filepath (str): Path to embeddings file
            
        Returns:
            np.ndarray: Loaded embeddings
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Embeddings file not found: {filepath}")
        
        with open(filepath, 'rb') as f:
            embeddings = pickle.load(f)
        
        print(f"✓ Embeddings loaded from {filepath}")
        
        return embeddings
    
    def compute_similarity(self, embedding1, embedding2):
        """
        Compute cosine similarity between two embeddings
        
        Args:
            embedding1 (np.ndarray): First embedding
            embedding2 (np.ndarray): Second embedding
            
        Returns:
            float: Similarity score (0 to 1, higher is more similar)
        """
        # Cosine similarity formula
        dot_product = np.dot(embedding1, embedding2)
        norm1 = np.linalg.norm(embedding1)
        norm2 = np.linalg.norm(embedding2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        similarity = dot_product / (norm1 * norm2)
        
        # Convert to 0-1 range (cosine similarity is -1 to 1)
        similarity = (similarity + 1) / 2
        
        return float(similarity)
    
    def get_model_info(self):
        """
        Get information about the loaded model
        
        Returns:
            dict: Model information
        """
        return {
            'model_name': self.model_name,
            'embedding_dimension': self.embedding_dim,
            'max_sequence_length': self.model.max_seq_length
        }


# Utility function for quick encoding
def encode_text(text, model_name='sentence-transformers/all-MiniLM-L6-v2'):
    """
    Quick function to encode a single text
    
    Args:
        text (str): Input text
        model_name (str): Model to use
        
    Returns:
        np.ndarray: Embedding vector
    """
    generator = EmbeddingGenerator(model_name)
    return generator.encode_text(text)


if __name__ == "__main__":
    # Test the embedding generator
    print("Testing Embedding Generator\n")
    print("=" * 50)
    
    # Initialize
    generator = EmbeddingGenerator()
    
    # Test single text
    test_text = "How do I borrow a book?"
    embedding = generator.encode_text(test_text)
    
    print(f"\nTest text: '{test_text}'")
    print(f"Embedding shape: {embedding.shape}")
    print(f"First 5 values: {embedding[:5]}")
    
    # Test similarity
    text1 = "How do I borrow a book?"
    text2 = "How can I check out a book?"
    text3 = "What is the weather today?"
    
    emb1 = generator.encode_text(text1)
    emb2 = generator.encode_text(text2)
    emb3 = generator.encode_text(text3)
    
    sim_12 = generator.compute_similarity(emb1, emb2)
    sim_13 = generator.compute_similarity(emb1, emb3)
    
    print(f"\n\nSimilarity Test:")
    print(f"Text 1: '{text1}'")
    print(f"Text 2: '{text2}'")
    print(f"Text 3: '{text3}'")
    print(f"\nSimilarity (1 vs 2): {sim_12:.4f} (should be high)")
    print(f"Similarity (1 vs 3): {sim_13:.4f} (should be low)")
    
    # Test batch encoding
    texts = [
        "How do I borrow a book?",
        "What is the borrowing period?",
        "How can I return a book?"
    ]
    
    embeddings = generator.encode_batch(texts, show_progress=False)
    print(f"\n\nBatch encoding test:")
    print(f"Encoded {len(texts)} texts")
    print(f"Embeddings shape: {embeddings.shape}")
