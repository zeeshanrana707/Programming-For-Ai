"""
Text Preprocessing Module
Cleans and normalizes text for better embedding quality
"""

import re
import string


class TextPreprocessor:
    """
    Handles text preprocessing for questions and answers
    """
    
    def __init__(self):
        """Initialize preprocessor with common patterns"""
        # Common library-specific terms to preserve
        self.preserve_terms = [
            'isbn', 'id', 'email', 'sci-fi', 'non-fiction'
        ]
    
    def clean_text(self, text):
        """
        Clean and normalize text
        
        Args:
            text (str): Raw input text
            
        Returns:
            str: Cleaned text
        """
        if not text:
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Preserve important terms before cleaning
        preserved = {}
        for term in self.preserve_terms:
            if term in text:
                placeholder = f"__PRESERVE_{term.upper()}__"
                preserved[placeholder] = term
                text = text.replace(term, placeholder)
        
        # Remove extra whitespace
        text = ' '.join(text.split())
        
        # Remove special characters but keep basic punctuation
        # Keep: letters, numbers, spaces, basic punctuation (.,!?)
        text = re.sub(r'[^\w\s.,!?\-]', '', text)
        
        # Restore preserved terms
        for placeholder, original in preserved.items():
            text = text.replace(placeholder, original)
        
        # Remove multiple punctuation
        text = re.sub(r'([.,!?])\1+', r'\1', text)
        
        # Trim whitespace
        text = text.strip()
        
        return text
    
    def preprocess_question(self, question):
        """
        Preprocess a user question
        
        Args:
            question (str): User's question
            
        Returns:
            str: Preprocessed question
        """
        # Clean the text
        cleaned = self.clean_text(question)
        
        # Remove question marks at the end (optional, helps matching)
        cleaned = cleaned.rstrip('?')
        
        return cleaned
    
    def preprocess_answer(self, answer):
        """
        Preprocess an answer (lighter processing)
        
        Args:
            answer (str): Answer text
            
        Returns:
            str: Preprocessed answer
        """
        # For answers, we do minimal processing to preserve formatting
        # Just normalize whitespace
        answer = ' '.join(answer.split())
        return answer.strip()
    
    def preprocess_dataset(self, qa_pairs):
        """
        Preprocess entire dataset
        
        Args:
            qa_pairs (list): List of QA dictionaries
            
        Returns:
            list: Preprocessed QA pairs
        """
        processed_pairs = []
        
        for pair in qa_pairs:
            processed_pair = {
                'id': pair['id'],
                'question': self.preprocess_question(pair['question']),
                'answer': self.preprocess_answer(pair['answer']),
                'category': pair.get('category', 'general'),
                'original_question': pair['question']  # Keep original for display
            }
            processed_pairs.append(processed_pair)
        
        return processed_pairs
    
    def normalize_query(self, query):
        """
        Normalize user query for searching
        Same as preprocess_question but with additional steps
        
        Args:
            query (str): User's search query
            
        Returns:
            str: Normalized query
        """
        # Use same preprocessing as questions
        normalized = self.preprocess_question(query)
        
        # Additional normalization for queries
        # Expand common abbreviations
        abbreviations = {
            'id': 'identification',
            'info': 'information',
            'stats': 'statistics'
        }
        
        words = normalized.split()
        normalized_words = [abbreviations.get(word, word) for word in words]
        normalized = ' '.join(normalized_words)
        
        return normalized


# Utility functions for quick access
def clean_text(text):
    """Quick function to clean text"""
    preprocessor = TextPreprocessor()
    return preprocessor.clean_text(text)


def preprocess_question(question):
    """Quick function to preprocess a question"""
    preprocessor = TextPreprocessor()
    return preprocessor.preprocess_question(question)


if __name__ == "__main__":
    # Test the preprocessor
    preprocessor = TextPreprocessor()
    
    # Test cases
    test_questions = [
        "How do I borrow a book???",
        "WHAT IS THE BORROWING PERIOD?",
        "Can I search for books by ISBN?",
        "   How   many   books   are   available?   "
    ]
    
    print("Testing Text Preprocessor\n")
    print("=" * 50)
    
    for q in test_questions:
        cleaned = preprocessor.preprocess_question(q)
        print(f"Original: {q}")
        print(f"Cleaned:  {cleaned}")
        print("-" * 50)
